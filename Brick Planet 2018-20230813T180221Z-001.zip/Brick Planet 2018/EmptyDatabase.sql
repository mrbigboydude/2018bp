-- --------------------------------------------------------
-- Host:                         127.0.0.1
-- Server version:               5.7.21-0ubuntu0.16.04.1 - (Ubuntu)
-- Server OS:                    Linux
-- HeidiSQL Version:             9.5.0.5196
-- --------------------------------------------------------

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET NAMES utf8 */;
/*!50503 SET NAMES utf8mb4 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;


-- Dumping database structure for test
CREATE DATABASE IF NOT EXISTS `test` /*!40100 DEFAULT CHARACTER SET latin1 */;
USE `test`;

-- Dumping structure for table test.Achievement
CREATE TABLE IF NOT EXISTS `Achievement` (
  `ID` int(11) NOT NULL AUTO_INCREMENT,
  `Category` int(11) DEFAULT '0',
  `Name` text,
  `Description` longtext,
  `Image` text,
  `Special` int(11) DEFAULT '0',
  PRIMARY KEY (`ID`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- Dumping data for table test.Achievement: ~0 rows (approximately)
/*!40000 ALTER TABLE `Achievement` DISABLE KEYS */;
/*!40000 ALTER TABLE `Achievement` ENABLE KEYS */;

-- Dumping structure for table test.AdminCommendations
CREATE TABLE IF NOT EXISTS `AdminCommendations` (
  `ID` int(11) NOT NULL AUTO_INCREMENT,
  `AdminID` int(11) DEFAULT NULL,
  `Message` longtext,
  `IssuerID` int(11) DEFAULT NULL,
  `Time` int(11) DEFAULT NULL,
  `Points` int(11) DEFAULT NULL,
  PRIMARY KEY (`ID`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- Dumping data for table test.AdminCommendations: ~0 rows (approximately)
/*!40000 ALTER TABLE `AdminCommendations` DISABLE KEYS */;
/*!40000 ALTER TABLE `AdminCommendations` ENABLE KEYS */;

-- Dumping structure for table test.AdminDiscipline
CREATE TABLE IF NOT EXISTS `AdminDiscipline` (
  `ID` int(11) NOT NULL AUTO_INCREMENT,
  `AdminID` int(11) DEFAULT NULL,
  `Message` longtext,
  `IssuerID` int(11) DEFAULT NULL,
  `Time` int(11) DEFAULT NULL,
  `Points` int(11) DEFAULT NULL,
  PRIMARY KEY (`ID`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- Dumping data for table test.AdminDiscipline: ~0 rows (approximately)
/*!40000 ALTER TABLE `AdminDiscipline` DISABLE KEYS */;
/*!40000 ALTER TABLE `AdminDiscipline` ENABLE KEYS */;

-- Dumping structure for table test.AdminEvents
CREATE TABLE IF NOT EXISTS `AdminEvents` (
  `ID` int(11) NOT NULL AUTO_INCREMENT,
  `Description` longtext,
  `Time` int(11) DEFAULT NULL,
  PRIMARY KEY (`ID`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- Dumping data for table test.AdminEvents: ~0 rows (approximately)
/*!40000 ALTER TABLE `AdminEvents` DISABLE KEYS */;
/*!40000 ALTER TABLE `AdminEvents` ENABLE KEYS */;

-- Dumping structure for table test.AdminEventsAttending
CREATE TABLE IF NOT EXISTS `AdminEventsAttending` (
  `ID` int(11) NOT NULL AUTO_INCREMENT,
  `EventID` int(11) DEFAULT NULL,
  `UserID` int(11) DEFAULT NULL,
  `AttendingStatus` int(11) DEFAULT NULL,
  PRIMARY KEY (`ID`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- Dumping data for table test.AdminEventsAttending: ~0 rows (approximately)
/*!40000 ALTER TABLE `AdminEventsAttending` DISABLE KEYS */;
/*!40000 ALTER TABLE `AdminEventsAttending` ENABLE KEYS */;

-- Dumping structure for table test.AdminFiles
CREATE TABLE IF NOT EXISTS `AdminFiles` (
  `ID` int(11) NOT NULL AUTO_INCREMENT,
  `UserID` int(11) DEFAULT NULL,
  `Points` int(11) DEFAULT '0',
  `SiteBannerAccess` int(11) DEFAULT '0',
  `PendingAssetsAccess` int(11) DEFAULT '1',
  `UserReportsAccess` int(11) DEFAULT '1',
  `ViewItemsAccess` int(11) DEFAULT '1',
  `ViewUsersAccess` int(11) DEFAULT '1',
  `ViewGroupsAccess` int(11) DEFAULT '1',
  `UploadAssetAccess` int(11) DEFAULT '0',
  `ViewAdminsAccess` int(11) DEFAULT '0',
  `ManageBlogAccess` int(11) DEFAULT '0',
  `PurchaseLogsAccess` int(11) DEFAULT '0',
  `SalesLogsAccess` int(11) DEFAULT '0',
  `AdminLogsAccess` int(11) DEFAULT '0',
  `ViewIPAccess` int(11) DEFAULT '0',
  `PersonnelAccess` int(11) DEFAULT '0',
  `OIGAccess` int(11) DEFAULT '0',
  `CommunityAffairsAccess` int(11) DEFAULT '0',
  `CustomerServiceAccess` int(11) DEFAULT '0',
  `SiteSettingsAccess` int(11) DEFAULT '0',
  `Reports` int(11) DEFAULT '0',
  PRIMARY KEY (`ID`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- Dumping data for table test.AdminFiles: ~0 rows (approximately)
/*!40000 ALTER TABLE `AdminFiles` DISABLE KEYS */;
/*!40000 ALTER TABLE `AdminFiles` ENABLE KEYS */;

-- Dumping structure for table test.AdministratorLogs
CREATE TABLE IF NOT EXISTS `AdministratorLogs` (
  `ID` int(11) NOT NULL AUTO_INCREMENT,
  `UserID` int(11) DEFAULT NULL,
  `IP` varchar(255) DEFAULT NULL,
  `Time` int(11) DEFAULT NULL,
  `Action` longtext,
  PRIMARY KEY (`ID`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- Dumping data for table test.AdministratorLogs: ~0 rows (approximately)
/*!40000 ALTER TABLE `AdministratorLogs` DISABLE KEYS */;
/*!40000 ALTER TABLE `AdministratorLogs` ENABLE KEYS */;

-- Dumping structure for table test.AdminReports
CREATE TABLE IF NOT EXISTS `AdminReports` (
  `ID` int(11) NOT NULL AUTO_INCREMENT,
  `ReportType` longtext,
  `Link` longtext,
  `Time` int(11) DEFAULT NULL,
  `Lock` int(11) DEFAULT '0',
  PRIMARY KEY (`ID`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- Dumping data for table test.AdminReports: ~0 rows (approximately)
/*!40000 ALTER TABLE `AdminReports` DISABLE KEYS */;
/*!40000 ALTER TABLE `AdminReports` ENABLE KEYS */;

-- Dumping structure for table test.AdminShifts
CREATE TABLE IF NOT EXISTS `AdminShifts` (
  `ID` int(11) NOT NULL AUTO_INCREMENT,
  `AdminID` int(11) DEFAULT NULL,
  `ShiftTime` int(11) DEFAULT NULL,
  `Reports` int(11) DEFAULT NULL,
  `Completed` int(11) DEFAULT NULL,
  PRIMARY KEY (`ID`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- Dumping data for table test.AdminShifts: ~0 rows (approximately)
/*!40000 ALTER TABLE `AdminShifts` DISABLE KEYS */;
/*!40000 ALTER TABLE `AdminShifts` ENABLE KEYS */;

-- Dumping structure for table test.AdminStatistics
CREATE TABLE IF NOT EXISTS `AdminStatistics` (
  `ID` int(11) NOT NULL AUTO_INCREMENT,
  `NumUsers` int(11) DEFAULT '0',
  `NumItems` int(11) DEFAULT '0',
  `NumGroups` int(11) DEFAULT '0',
  PRIMARY KEY (`ID`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- Dumping data for table test.AdminStatistics: ~0 rows (approximately)
/*!40000 ALTER TABLE `AdminStatistics` DISABLE KEYS */;
/*!40000 ALTER TABLE `AdminStatistics` ENABLE KEYS */;

-- Dumping structure for table test.AdminTasks
CREATE TABLE IF NOT EXISTS `AdminTasks` (
  `ID` int(11) NOT NULL AUTO_INCREMENT,
  `UserID` int(11) DEFAULT NULL,
  `AssignedBy` int(11) DEFAULT NULL,
  `Description` varchar(256) DEFAULT NULL,
  `TimeAssigned` int(11) DEFAULT NULL,
  `TimeDue` int(11) DEFAULT NULL,
  `RepeatInterval` int(11) DEFAULT NULL,
  `Response` longtext,
  `Completed` int(11) DEFAULT NULL,
  PRIMARY KEY (`ID`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- Dumping data for table test.AdminTasks: ~0 rows (approximately)
/*!40000 ALTER TABLE `AdminTasks` DISABLE KEYS */;
/*!40000 ALTER TABLE `AdminTasks` ENABLE KEYS */;

-- Dumping structure for table test.AssetChecksum
CREATE TABLE IF NOT EXISTS `AssetChecksum` (
  `FileName` varchar(128) DEFAULT NULL,
  `Hash` varchar(128) DEFAULT NULL,
  `Status` tinyint(4) DEFAULT NULL COMMENT '0 - Pending\n1 - Accepted\n2 - Declined',
  `TimeCreated` int(11) DEFAULT NULL,
  `Frequency` int(11) DEFAULT '1'
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- Dumping data for table test.AssetChecksum: ~0 rows (approximately)
/*!40000 ALTER TABLE `AssetChecksum` DISABLE KEYS */;
/*!40000 ALTER TABLE `AssetChecksum` ENABLE KEYS */;

-- Dumping structure for table test.AssetChecksums
CREATE TABLE IF NOT EXISTS `AssetChecksums` (
  `ID` int(11) NOT NULL AUTO_INCREMENT,
  `Checksum` varchar(256) DEFAULT NULL,
  `ViewFile` varchar(128) DEFAULT NULL,
  `Approved` int(11) DEFAULT '0',
  `AssetType` int(11) DEFAULT '0',
  PRIMARY KEY (`ID`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- Dumping data for table test.AssetChecksums: ~0 rows (approximately)
/*!40000 ALTER TABLE `AssetChecksums` DISABLE KEYS */;
/*!40000 ALTER TABLE `AssetChecksums` ENABLE KEYS */;

-- Dumping structure for table test.AssetModerationLogs
CREATE TABLE IF NOT EXISTS `AssetModerationLogs` (
  `ID` int(11) NOT NULL AUTO_INCREMENT,
  `AdminID` int(11) DEFAULT NULL,
  `Message` varchar(255) DEFAULT NULL,
  `LogTime` int(11) DEFAULT NULL,
  `IP` varchar(100) DEFAULT NULL,
  PRIMARY KEY (`ID`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- Dumping data for table test.AssetModerationLogs: ~0 rows (approximately)
/*!40000 ALTER TABLE `AssetModerationLogs` DISABLE KEYS */;
/*!40000 ALTER TABLE `AssetModerationLogs` ENABLE KEYS */;

-- Dumping structure for table test.AvatarUpdateQueue
CREATE TABLE IF NOT EXISTS `AvatarUpdateQueue` (
  `ID` int(11) NOT NULL AUTO_INCREMENT,
  `UserID` int(11) DEFAULT NULL,
  `Locked` int(11) DEFAULT '0',
  PRIMARY KEY (`ID`),
  UNIQUE KEY `AvatarUpdateQueue_UserID_Unique` (`UserID`),
  KEY `AvatarUpdateQueue_UserID_FK_idx` (`UserID`),
  CONSTRAINT `AvatarUpdateQueue_UserID_FK` FOREIGN KEY (`UserID`) REFERENCES `User` (`ID`) ON DELETE NO ACTION ON UPDATE NO ACTION
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- Dumping data for table test.AvatarUpdateQueue: ~0 rows (approximately)
/*!40000 ALTER TABLE `AvatarUpdateQueue` DISABLE KEYS */;
/*!40000 ALTER TABLE `AvatarUpdateQueue` ENABLE KEYS */;

-- Dumping structure for table test.BanLogs
CREATE TABLE IF NOT EXISTS `BanLogs` (
  `ID` int(11) NOT NULL AUTO_INCREMENT,
  `AdminID` int(11) DEFAULT NULL,
  `Message` varchar(255) DEFAULT NULL,
  `LogTime` int(11) DEFAULT NULL,
  `IP` varchar(100) DEFAULT NULL,
  PRIMARY KEY (`ID`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- Dumping data for table test.BanLogs: ~0 rows (approximately)
/*!40000 ALTER TABLE `BanLogs` DISABLE KEYS */;
/*!40000 ALTER TABLE `BanLogs` ENABLE KEYS */;

-- Dumping structure for table test.BlockedEmail
CREATE TABLE IF NOT EXISTS `BlockedEmail` (
  `ID` int(11) NOT NULL AUTO_INCREMENT,
  `Email` varchar(128) DEFAULT NULL,
  PRIMARY KEY (`ID`),
  KEY `BlockedEmail_Email_Index` (`Email`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- Dumping data for table test.BlockedEmail: ~0 rows (approximately)
/*!40000 ALTER TABLE `BlockedEmail` DISABLE KEYS */;
/*!40000 ALTER TABLE `BlockedEmail` ENABLE KEYS */;

-- Dumping structure for table test.BlockedUser
CREATE TABLE IF NOT EXISTS `BlockedUser` (
  `ID` int(11) NOT NULL AUTO_INCREMENT,
  `RequesterID` int(11) DEFAULT NULL,
  `BlockedID` int(11) DEFAULT NULL,
  `Time` int(11) DEFAULT NULL,
  PRIMARY KEY (`ID`),
  UNIQUE KEY `BlockedUser_Unique` (`RequesterID`,`BlockedID`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- Dumping data for table test.BlockedUser: ~0 rows (approximately)
/*!40000 ALTER TABLE `BlockedUser` DISABLE KEYS */;
/*!40000 ALTER TABLE `BlockedUser` ENABLE KEYS */;

-- Dumping structure for table test.BlockedUsername
CREATE TABLE IF NOT EXISTS `BlockedUsername` (
  `ID` int(11) NOT NULL AUTO_INCREMENT,
  `Username` varchar(20) DEFAULT NULL,
  PRIMARY KEY (`ID`),
  KEY `BlockedUsername_Username_Index` (`Username`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- Dumping data for table test.BlockedUsername: ~0 rows (approximately)
/*!40000 ALTER TABLE `BlockedUsername` DISABLE KEYS */;
/*!40000 ALTER TABLE `BlockedUsername` ENABLE KEYS */;

-- Dumping structure for table test.DirectChat
CREATE TABLE IF NOT EXISTS `DirectChat` (
  `ID` int(11) NOT NULL AUTO_INCREMENT,
  `SenderID` int(11) DEFAULT NULL,
  `ReceiverID` int(11) DEFAULT NULL,
  `Message` varchar(256) DEFAULT NULL,
  `Time` int(11) DEFAULT NULL,
  `Type` int(11) DEFAULT '0' COMMENT '0 - Chat\n1 - Notification\n2 - Module',
  `Read` int(11) DEFAULT '0',
  PRIMARY KEY (`ID`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- Dumping data for table test.DirectChat: ~0 rows (approximately)
/*!40000 ALTER TABLE `DirectChat` DISABLE KEYS */;
/*!40000 ALTER TABLE `DirectChat` ENABLE KEYS */;

-- Dumping structure for table test.EmailBlacklist
CREATE TABLE IF NOT EXISTS `EmailBlacklist` (
  `ID` int(11) NOT NULL AUTO_INCREMENT,
  `Email` varchar(45) DEFAULT 'NULL',
  PRIMARY KEY (`ID`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- Dumping data for table test.EmailBlacklist: ~0 rows (approximately)
/*!40000 ALTER TABLE `EmailBlacklist` DISABLE KEYS */;
/*!40000 ALTER TABLE `EmailBlacklist` ENABLE KEYS */;

-- Dumping structure for table test.EmailQueue
CREATE TABLE IF NOT EXISTS `EmailQueue` (
  `ID` int(11) NOT NULL AUTO_INCREMENT,
  `UserID` int(11) DEFAULT NULL,
  `Type` int(11) DEFAULT NULL,
  `Time` int(11) DEFAULT NULL,
  `IP` varchar(60) DEFAULT NULL,
  `Email` varchar(100) DEFAULT NULL,
  `RevertCode` varchar(256) DEFAULT NULL,
  `Processing` int(11) DEFAULT '0',
  PRIMARY KEY (`ID`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- Dumping data for table test.EmailQueue: ~0 rows (approximately)
/*!40000 ALTER TABLE `EmailQueue` DISABLE KEYS */;
/*!40000 ALTER TABLE `EmailQueue` ENABLE KEYS */;

-- Dumping structure for table test.EmojiList
CREATE TABLE IF NOT EXISTS `EmojiList` (
  `ID` int(11) NOT NULL AUTO_INCREMENT,
  `Name` varchar(50) DEFAULT NULL,
  `Description` varchar(128) DEFAULT NULL,
  PRIMARY KEY (`ID`),
  FULLTEXT KEY `EmojiList_Description` (`Description`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- Dumping data for table test.EmojiList: ~0 rows (approximately)
/*!40000 ALTER TABLE `EmojiList` DISABLE KEYS */;
/*!40000 ALTER TABLE `EmojiList` ENABLE KEYS */;

-- Dumping structure for table test.FavoriteFriend
CREATE TABLE IF NOT EXISTS `FavoriteFriend` (
  `ID` int(11) NOT NULL AUTO_INCREMENT,
  `UserID` int(11) DEFAULT NULL,
  `TargetID` int(11) DEFAULT NULL,
  PRIMARY KEY (`ID`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- Dumping data for table test.FavoriteFriend: ~0 rows (approximately)
/*!40000 ALTER TABLE `FavoriteFriend` DISABLE KEYS */;
/*!40000 ALTER TABLE `FavoriteFriend` ENABLE KEYS */;

-- Dumping structure for table test.ForumAdminLog
CREATE TABLE IF NOT EXISTS `ForumAdminLog` (
  `ID` int(11) NOT NULL AUTO_INCREMENT,
  `ForumType` int(11) DEFAULT NULL,
  `ForumID` int(11) DEFAULT NULL,
  `AdminID` int(11) DEFAULT NULL,
  `UserID` int(11) DEFAULT NULL,
  `TimeAction` int(11) DEFAULT NULL,
  `ActionIP` varchar(60) DEFAULT NULL,
  `ActionDescription` varchar(128) DEFAULT NULL,
  PRIMARY KEY (`ID`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- Dumping data for table test.ForumAdminLog: ~0 rows (approximately)
/*!40000 ALTER TABLE `ForumAdminLog` DISABLE KEYS */;
/*!40000 ALTER TABLE `ForumAdminLog` ENABLE KEYS */;

-- Dumping structure for table test.ForumBan
CREATE TABLE IF NOT EXISTS `ForumBan` (
  `ID` int(11) NOT NULL,
  `UserID` int(11) DEFAULT '0',
  `Reason` longtext,
  PRIMARY KEY (`ID`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- Dumping data for table test.ForumBan: ~0 rows (approximately)
/*!40000 ALTER TABLE `ForumBan` DISABLE KEYS */;
/*!40000 ALTER TABLE `ForumBan` ENABLE KEYS */;

-- Dumping structure for table test.ForumCategory
CREATE TABLE IF NOT EXISTS `ForumCategory` (
  `ID` int(11) NOT NULL AUTO_INCREMENT,
  `Name` varchar(128) DEFAULT NULL,
  PRIMARY KEY (`ID`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=latin1;

-- Dumping data for table test.ForumCategory: ~0 rows (approximately)
/*!40000 ALTER TABLE `ForumCategory` DISABLE KEYS */;
REPLACE INTO `ForumCategory` (`ID`, `Name`) VALUES
	(1, 'll');
/*!40000 ALTER TABLE `ForumCategory` ENABLE KEYS */;

-- Dumping structure for table test.ForumReply
CREATE TABLE IF NOT EXISTS `ForumReply` (
  `ID` int(11) NOT NULL AUTO_INCREMENT,
  `ThreadID` int(11) DEFAULT NULL,
  `UserID` int(11) DEFAULT NULL,
  `Post` longtext,
  `TimePost` int(11) DEFAULT NULL,
  `QuoteType` int(11) DEFAULT '0',
  `QuoteID` int(11) DEFAULT '0',
  PRIMARY KEY (`ID`),
  KEY `ForumReply_TimePost_Index` (`TimePost`),
  KEY `ForumReplyy_UserID_FK_idx` (`UserID`),
  KEY `ForumReplyy_ThreadID_FK_idx` (`ThreadID`),
  FULLTEXT KEY `ForumReply_Post_FT` (`Post`),
  CONSTRAINT `ForumReplyy_ThreadID_FK` FOREIGN KEY (`ThreadID`) REFERENCES `ForumThread` (`ID`) ON DELETE NO ACTION ON UPDATE NO ACTION,
  CONSTRAINT `ForumReplyy_UserID_FK` FOREIGN KEY (`UserID`) REFERENCES `User` (`ID`) ON DELETE NO ACTION ON UPDATE NO ACTION
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- Dumping data for table test.ForumReply: ~0 rows (approximately)
/*!40000 ALTER TABLE `ForumReply` DISABLE KEYS */;
/*!40000 ALTER TABLE `ForumReply` ENABLE KEYS */;

-- Dumping structure for table test.ForumReplyLike
CREATE TABLE IF NOT EXISTS `ForumReplyLike` (
  `ID` int(11) NOT NULL AUTO_INCREMENT,
  `ReplyID` int(11) DEFAULT NULL,
  `UserID` int(11) DEFAULT NULL,
  `TimeLike` int(11) DEFAULT NULL,
  PRIMARY KEY (`ID`),
  KEY `ForumReplyLike_ReplyID_FK_idx` (`ReplyID`),
  KEY `ForumReplyLike_UserID_FK_idx` (`UserID`),
  CONSTRAINT `ForumReplyLike_ReplyID_FK` FOREIGN KEY (`ReplyID`) REFERENCES `ForumReply` (`ID`) ON DELETE NO ACTION ON UPDATE NO ACTION,
  CONSTRAINT `ForumReplyLike_UserID_FK` FOREIGN KEY (`UserID`) REFERENCES `User` (`ID`) ON DELETE NO ACTION ON UPDATE NO ACTION
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- Dumping data for table test.ForumReplyLike: ~0 rows (approximately)
/*!40000 ALTER TABLE `ForumReplyLike` DISABLE KEYS */;
/*!40000 ALTER TABLE `ForumReplyLike` ENABLE KEYS */;

-- Dumping structure for table test.ForumThread
CREATE TABLE IF NOT EXISTS `ForumThread` (
  `ID` int(11) NOT NULL AUTO_INCREMENT,
  `TopicID` int(11) DEFAULT NULL,
  `UserID` int(11) DEFAULT NULL,
  `Title` varchar(128) DEFAULT NULL,
  `Post` longtext,
  `TimePost` int(11) DEFAULT NULL,
  `TimeUpdated` int(11) DEFAULT NULL,
  `Likes` int(11) DEFAULT '0',
  `Locked` int(11) DEFAULT '0',
  `Pinned` int(11) DEFAULT '0',
  `Views` int(11) DEFAULT '0',
  `Replies` int(11) DEFAULT '0',
  `LastPostReplyID` int(11) DEFAULT '0',
  PRIMARY KEY (`ID`),
  KEY `ForumThread_UserID_FK_idx` (`UserID`),
  KEY `ForumThread_TopicID_FK_idx` (`TopicID`),
  KEY `ForumThread_TimeUpdated_Index` (`TimeUpdated`),
  KEY `ForumThread_Locked_Index` (`Locked`),
  KEY `ForumThread_Pinned_Index` (`Pinned`),
  KEY `ForumThread_Combined_Index` (`UserID`,`TopicID`),
  FULLTEXT KEY `ForumThread_Title_FT` (`Title`),
  FULLTEXT KEY `ForumThread_Post_FT` (`Post`),
  CONSTRAINT `ForumThread_TopicID_FK` FOREIGN KEY (`TopicID`) REFERENCES `ForumTopic` (`ID`) ON DELETE NO ACTION ON UPDATE NO ACTION,
  CONSTRAINT `ForumThread_UserID_FK` FOREIGN KEY (`UserID`) REFERENCES `User` (`ID`) ON DELETE NO ACTION ON UPDATE NO ACTION
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=latin1;

-- Dumping data for table test.ForumThread: ~0 rows (approximately)
/*!40000 ALTER TABLE `ForumThread` DISABLE KEYS */;
REPLACE INTO `ForumThread` (`ID`, `TopicID`, `UserID`, `Title`, `Post`, `TimePost`, `TimeUpdated`, `Likes`, `Locked`, `Pinned`, `Views`, `Replies`, `LastPostReplyID`) VALUES
	(1, 1, 172480, 'test', 'hi', 9, 9, 0, 0, 0, 0, 0, 0);
/*!40000 ALTER TABLE `ForumThread` ENABLE KEYS */;

-- Dumping structure for table test.ForumThreadBookmark
CREATE TABLE IF NOT EXISTS `ForumThreadBookmark` (
  `UserID` int(11) DEFAULT NULL,
  `ThreadID` int(11) DEFAULT NULL,
  KEY `ForumThreadBookmark_UserID_FK_idx` (`UserID`),
  KEY `ForumThreadBookmark_ThreadID_FK_idx` (`ThreadID`),
  CONSTRAINT `ForumThreadBookmark_ThreadID_FK` FOREIGN KEY (`ThreadID`) REFERENCES `ForumThread` (`ID`) ON DELETE NO ACTION ON UPDATE NO ACTION,
  CONSTRAINT `ForumThreadBookmark_UserID_FK` FOREIGN KEY (`UserID`) REFERENCES `User` (`ID`) ON DELETE NO ACTION ON UPDATE NO ACTION
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- Dumping data for table test.ForumThreadBookmark: ~0 rows (approximately)
/*!40000 ALTER TABLE `ForumThreadBookmark` DISABLE KEYS */;
/*!40000 ALTER TABLE `ForumThreadBookmark` ENABLE KEYS */;

-- Dumping structure for table test.ForumThreadDraft
CREATE TABLE IF NOT EXISTS `ForumThreadDraft` (
  `ID` int(11) NOT NULL AUTO_INCREMENT,
  `Title` varchar(40) DEFAULT NULL,
  `Post` longtext,
  `UserID` int(11) DEFAULT NULL,
  `TopicID` int(11) DEFAULT NULL,
  `TimePost` int(11) DEFAULT NULL,
  PRIMARY KEY (`ID`),
  KEY `ForumThreadDraft_UserID_FK_idx` (`UserID`),
  KEY `ForumThreadDraft_TopicID_FK_idx` (`TopicID`),
  KEY `ForumThread_TimePost_Index` (`TimePost`),
  CONSTRAINT `ForumThreadDraft_TopicID_FK` FOREIGN KEY (`TopicID`) REFERENCES `ForumTopic` (`ID`) ON DELETE NO ACTION ON UPDATE NO ACTION,
  CONSTRAINT `ForumThreadDraft_UserID_FK` FOREIGN KEY (`UserID`) REFERENCES `User` (`ID`) ON DELETE NO ACTION ON UPDATE NO ACTION
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- Dumping data for table test.ForumThreadDraft: ~0 rows (approximately)
/*!40000 ALTER TABLE `ForumThreadDraft` DISABLE KEYS */;
/*!40000 ALTER TABLE `ForumThreadDraft` ENABLE KEYS */;

-- Dumping structure for table test.ForumThreadLike
CREATE TABLE IF NOT EXISTS `ForumThreadLike` (
  `ThreadID` int(11) DEFAULT NULL,
  `UserID` int(11) DEFAULT NULL,
  `TimeLike` int(11) DEFAULT NULL,
  `Active` int(11) NOT NULL DEFAULT '1',
  KEY `ForumThread_ThreadID_FK_idx` (`ThreadID`),
  KEY `ForumThreadLike_UserID_FK_idx` (`UserID`),
  KEY `ForumThreadLike_TimeLike_Index` (`TimeLike`),
  KEY `ForumThread_Active_Index` (`Active`),
  CONSTRAINT `ForumThreadLike_ThreadID_FK` FOREIGN KEY (`ThreadID`) REFERENCES `ForumThread` (`ID`) ON DELETE NO ACTION ON UPDATE NO ACTION,
  CONSTRAINT `ForumThreadLike_UserID_FK` FOREIGN KEY (`UserID`) REFERENCES `User` (`ID`) ON DELETE NO ACTION ON UPDATE NO ACTION
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- Dumping data for table test.ForumThreadLike: ~0 rows (approximately)
/*!40000 ALTER TABLE `ForumThreadLike` DISABLE KEYS */;
/*!40000 ALTER TABLE `ForumThreadLike` ENABLE KEYS */;

-- Dumping structure for table test.ForumThreadView
CREATE TABLE IF NOT EXISTS `ForumThreadView` (
  `ID` int(11) NOT NULL AUTO_INCREMENT,
  `ThreadID` int(11) DEFAULT NULL,
  `UserID` int(11) DEFAULT NULL,
  `TimeView` int(11) DEFAULT NULL,
  PRIMARY KEY (`ID`),
  KEY `ForumThreadView_ThreadID_FK_idx` (`ThreadID`),
  KEY `ForumThreadView_UserID_FK_idx` (`UserID`),
  CONSTRAINT `ForumThreadView_ThreadID_FK` FOREIGN KEY (`ThreadID`) REFERENCES `ForumThread` (`ID`) ON DELETE NO ACTION ON UPDATE NO ACTION,
  CONSTRAINT `ForumThreadView_UserID_FK` FOREIGN KEY (`UserID`) REFERENCES `User` (`ID`) ON DELETE NO ACTION ON UPDATE NO ACTION
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- Dumping data for table test.ForumThreadView: ~0 rows (approximately)
/*!40000 ALTER TABLE `ForumThreadView` DISABLE KEYS */;
/*!40000 ALTER TABLE `ForumThreadView` ENABLE KEYS */;

-- Dumping structure for table test.ForumTopic
CREATE TABLE IF NOT EXISTS `ForumTopic` (
  `ID` int(11) NOT NULL AUTO_INCREMENT,
  `CategoryID` int(11) DEFAULT NULL,
  `Name` varchar(128) DEFAULT NULL,
  `Description` varchar(128) DEFAULT NULL,
  `Posts` int(11) DEFAULT '0',
  `Replies` int(11) DEFAULT '0',
  `LastPostThreadID` int(11) DEFAULT NULL,
  `LastPostReplyID` int(11) DEFAULT NULL,
  `AdminPost` int(11) DEFAULT '0',
  `Sort` int(11) DEFAULT '1',
  PRIMARY KEY (`ID`),
  KEY `ForumTopic_CategoryID_FK_idx` (`CategoryID`),
  KEY `ForumTopic_Sort_Index` (`Sort`),
  CONSTRAINT `ForumTopic_CategoryID_FK` FOREIGN KEY (`CategoryID`) REFERENCES `ForumCategory` (`ID`) ON DELETE NO ACTION ON UPDATE NO ACTION
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=latin1;

-- Dumping data for table test.ForumTopic: ~1 rows (approximately)
/*!40000 ALTER TABLE `ForumTopic` DISABLE KEYS */;
REPLACE INTO `ForumTopic` (`ID`, `CategoryID`, `Name`, `Description`, `Posts`, `Replies`, `LastPostThreadID`, `LastPostReplyID`, `AdminPost`, `Sort`) VALUES
	(1, 1, 'Announcements', 'Official information and updates are posted by staff members in this area.', 1, 0, 1, 90, 1, 1),
	(2, 1, 'General Discussion', '<b>xss</b>', 0, 0, 0, 0, 1, 1);
/*!40000 ALTER TABLE `ForumTopic` ENABLE KEYS */;

-- Dumping structure for table test.Friend
CREATE TABLE IF NOT EXISTS `Friend` (
  `ID` int(11) NOT NULL AUTO_INCREMENT,
  `SenderID` int(11) DEFAULT NULL,
  `ReceiverID` int(11) DEFAULT NULL,
  `TimeSent` int(11) DEFAULT NULL,
  `Accepted` int(11) DEFAULT NULL,
  PRIMARY KEY (`ID`),
  KEY `Friend_SenderID_FK_idx` (`SenderID`),
  KEY `Friend_ReceiverID_FK_idx` (`ReceiverID`),
  KEY `Friend_TimeSent_Index` (`TimeSent`),
  KEY `Friend_Accepted_Index` (`Accepted`),
  CONSTRAINT `Friend_ReceiverID_FK` FOREIGN KEY (`ReceiverID`) REFERENCES `User` (`ID`) ON DELETE NO ACTION ON UPDATE NO ACTION,
  CONSTRAINT `Friend_SenderID_FK` FOREIGN KEY (`SenderID`) REFERENCES `User` (`ID`) ON DELETE NO ACTION ON UPDATE NO ACTION
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- Dumping data for table test.Friend: ~0 rows (approximately)
/*!40000 ALTER TABLE `Friend` DISABLE KEYS */;
/*!40000 ALTER TABLE `Friend` ENABLE KEYS */;

-- Dumping structure for table test.IPBan
CREATE TABLE IF NOT EXISTS `IPBan` (
  `ID` int(11) NOT NULL AUTO_INCREMENT,
  `AdminID` int(11) DEFAULT NULL,
  `IP` varchar(60) DEFAULT NULL,
  `Reason` varchar(128) DEFAULT NULL,
  `TimePlaced` int(11) DEFAULT NULL,
  `TimeExpire` int(11) DEFAULT NULL,
  PRIMARY KEY (`ID`),
  KEY `IPBan_AdminID_FK_idx` (`AdminID`),
  KEY `IPBan_IP_Index` (`IP`),
  KEY `IPBan_TimePlaced_Index` (`TimePlaced`),
  KEY `IPBan_TimeExpire_Index` (`TimeExpire`),
  CONSTRAINT `IPBan_AdminID_FK` FOREIGN KEY (`AdminID`) REFERENCES `User` (`ID`) ON DELETE NO ACTION ON UPDATE NO ACTION
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- Dumping data for table test.IPBan: ~0 rows (approximately)
/*!40000 ALTER TABLE `IPBan` DISABLE KEYS */;
/*!40000 ALTER TABLE `IPBan` ENABLE KEYS */;

-- Dumping structure for table test.Item
CREATE TABLE IF NOT EXISTS `Item` (
  `ID` int(11) NOT NULL AUTO_INCREMENT,
  `ItemType` tinyint(4) DEFAULT NULL,
  `Name` varchar(70) DEFAULT NULL,
  `Description` varchar(1024) DEFAULT NULL,
  `CreatorID` int(11) DEFAULT NULL,
  `CreatorType` tinyint(4) DEFAULT '0',
  `TimeCreated` int(11) DEFAULT NULL,
  `TimeUpdated` int(11) DEFAULT NULL,
  `Cost` int(11) DEFAULT '1',
  `CostCredits` int(11) DEFAULT '0',
  `SaleActive` tinyint(4) DEFAULT '1',
  `PreviewImage` varchar(128) DEFAULT NULL,
  `ShadowImage` varchar(128) DEFAULT NULL,
  `ThumbnailImage` varchar(128) DEFAULT NULL,
  `BackendFile` varchar(128) DEFAULT NULL,
  `BackendFileBlink` varchar(128) DEFAULT NULL,
  `TextureOne` varchar(128) DEFAULT NULL,
  `TextureTwo` varchar(128) DEFAULT NULL,
  `TextureThree` varchar(128) DEFAULT NULL,
  `IsCollectible` tinyint(4) DEFAULT '0',
  `InitialStock` int(11) DEFAULT '0',
  `RemainingStock` int(11) DEFAULT '0',
  `NumberCopies` int(11) unsigned DEFAULT '0',
  `NumberFavorites` int(11) unsigned DEFAULT '0',
  `PublicView` tinyint(4) DEFAULT '1',
  `TimeOffSale` int(11) DEFAULT '0',
  `ImpressionCount` int(11) unsigned DEFAULT '0',
  `ItemSellerCount` int(11) unsigned DEFAULT '0',
  `TradeLock` tinyint(4) DEFAULT '0',
  `ItemZoom` float DEFAULT '0',
  PRIMARY KEY (`ID`),
  KEY `Item_ItemType_Index` (`ItemType`),
  KEY `Item_TimeUpdated_Index` (`TimeUpdated`),
  KEY `Item_PublicView_Index` (`PublicView`),
  KEY `Item_PreviewImage_Index` (`PreviewImage`),
  KEY `Item_TimeCreated_Index` (`TimeCreated`),
  FULLTEXT KEY `Item_Name_FT` (`Name`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- Dumping data for table test.Item: ~0 rows (approximately)
/*!40000 ALTER TABLE `Item` DISABLE KEYS */;
/*!40000 ALTER TABLE `Item` ENABLE KEYS */;

-- Dumping structure for table test.ItemComment
CREATE TABLE IF NOT EXISTS `ItemComment` (
  `ID` int(11) NOT NULL AUTO_INCREMENT,
  `ItemID` int(11) DEFAULT NULL,
  `UserID` int(11) DEFAULT NULL,
  `Comment` longtext,
  `TimeOfPost` int(11) DEFAULT NULL,
  PRIMARY KEY (`ID`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- Dumping data for table test.ItemComment: ~0 rows (approximately)
/*!40000 ALTER TABLE `ItemComment` DISABLE KEYS */;
/*!40000 ALTER TABLE `ItemComment` ENABLE KEYS */;

-- Dumping structure for table test.ItemCrateContent
CREATE TABLE IF NOT EXISTS `ItemCrateContent` (
  `ID` int(11) NOT NULL AUTO_INCREMENT,
  `ItemID` int(11) DEFAULT NULL,
  `ContentRarity` int(11) DEFAULT NULL,
  `ContentType` int(11) DEFAULT NULL,
  `ContentID` int(11) DEFAULT NULL,
  `ContentValue` int(11) DEFAULT NULL,
  `ContentQuantity` int(11) DEFAULT NULL,
  `QuantityRemaining` int(11) DEFAULT NULL,
  PRIMARY KEY (`ID`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- Dumping data for table test.ItemCrateContent: ~0 rows (approximately)
/*!40000 ALTER TABLE `ItemCrateContent` DISABLE KEYS */;
/*!40000 ALTER TABLE `ItemCrateContent` ENABLE KEYS */;

-- Dumping structure for table test.ItemCrateLog
CREATE TABLE IF NOT EXISTS `ItemCrateLog` (
  `ID` int(11) NOT NULL AUTO_INCREMENT,
  `ItemID` int(11) DEFAULT NULL,
  `UserID` int(11) DEFAULT NULL,
  `Text` varchar(256) DEFAULT NULL,
  `TimeLog` int(11) DEFAULT NULL,
  PRIMARY KEY (`ID`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- Dumping data for table test.ItemCrateLog: ~0 rows (approximately)
/*!40000 ALTER TABLE `ItemCrateLog` DISABLE KEYS */;
/*!40000 ALTER TABLE `ItemCrateLog` ENABLE KEYS */;

-- Dumping structure for table test.ItemFavorite
CREATE TABLE IF NOT EXISTS `ItemFavorite` (
  `UserID` int(11) DEFAULT NULL,
  `ItemID` int(11) DEFAULT NULL,
  `Time` int(11) DEFAULT NULL,
  `IP` varchar(100) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- Dumping data for table test.ItemFavorite: ~0 rows (approximately)
/*!40000 ALTER TABLE `ItemFavorite` DISABLE KEYS */;
/*!40000 ALTER TABLE `ItemFavorite` ENABLE KEYS */;

-- Dumping structure for table test.ItemImpression
CREATE TABLE IF NOT EXISTS `ItemImpression` (
  `ID` int(11) NOT NULL AUTO_INCREMENT,
  `ItemID` int(11) DEFAULT NULL,
  `UserID` int(11) DEFAULT NULL,
  PRIMARY KEY (`ID`),
  KEY `ItemImpression_ItemID_FK_idx` (`ItemID`),
  CONSTRAINT `ItemImpression_ItemID_FK` FOREIGN KEY (`ItemID`) REFERENCES `Item` (`ID`) ON DELETE NO ACTION ON UPDATE NO ACTION
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- Dumping data for table test.ItemImpression: ~0 rows (approximately)
/*!40000 ALTER TABLE `ItemImpression` DISABLE KEYS */;
/*!40000 ALTER TABLE `ItemImpression` ENABLE KEYS */;

-- Dumping structure for table test.ItemSalesHistory
CREATE TABLE IF NOT EXISTS `ItemSalesHistory` (
  `ID` int(11) NOT NULL AUTO_INCREMENT,
  `BuyerID` int(11) DEFAULT NULL,
  `CreatorID` int(11) DEFAULT NULL,
  `ItemID` int(11) DEFAULT NULL,
  `Price` int(11) DEFAULT NULL,
  `Time` int(11) DEFAULT NULL,
  `PaymentType` varchar(45) DEFAULT NULL,
  `InventoryID` int(11) DEFAULT '0',
  PRIMARY KEY (`ID`),
  KEY `ItemSalesHistory_ItemID_FK_idx` (`ItemID`),
  KEY `ItemSalesHistory_Time_Index` (`Time`),
  KEY `ItemSalesHistory_UserID_FK_idx` (`BuyerID`),
  CONSTRAINT `ItemSalesHistory_BuyerID_FK` FOREIGN KEY (`BuyerID`) REFERENCES `User` (`ID`) ON DELETE NO ACTION ON UPDATE NO ACTION,
  CONSTRAINT `ItemSalesHistory_ItemID_FK` FOREIGN KEY (`ItemID`) REFERENCES `Item` (`ID`) ON DELETE NO ACTION ON UPDATE NO ACTION
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- Dumping data for table test.ItemSalesHistory: ~0 rows (approximately)
/*!40000 ALTER TABLE `ItemSalesHistory` DISABLE KEYS */;
/*!40000 ALTER TABLE `ItemSalesHistory` ENABLE KEYS */;

-- Dumping structure for table test.ItemSeller
CREATE TABLE IF NOT EXISTS `ItemSeller` (
  `ID` int(11) NOT NULL AUTO_INCREMENT,
  `ItemID` int(11) DEFAULT NULL,
  `InventoryID` int(11) DEFAULT NULL,
  `UserID` int(11) DEFAULT NULL,
  `Price` int(11) DEFAULT NULL,
  `TimeCreated` int(11) DEFAULT NULL,
  PRIMARY KEY (`ID`),
  UNIQUE KEY `ItemSeller_Unique` (`ItemID`,`InventoryID`,`UserID`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- Dumping data for table test.ItemSeller: ~0 rows (approximately)
/*!40000 ALTER TABLE `ItemSeller` DISABLE KEYS */;
/*!40000 ALTER TABLE `ItemSeller` ENABLE KEYS */;

-- Dumping structure for table test.ItemSellerHistory
CREATE TABLE IF NOT EXISTS `ItemSellerHistory` (
  `ID` int(11) NOT NULL AUTO_INCREMENT,
  `UTLID` int(11) DEFAULT NULL,
  `ItemID` int(11) DEFAULT NULL,
  `SellerID` int(11) DEFAULT NULL,
  `BuyerID` int(11) DEFAULT NULL,
  `Price` int(11) DEFAULT NULL,
  `TimeSale` int(11) DEFAULT NULL,
  PRIMARY KEY (`ID`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- Dumping data for table test.ItemSellerHistory: ~0 rows (approximately)
/*!40000 ALTER TABLE `ItemSellerHistory` DISABLE KEYS */;
/*!40000 ALTER TABLE `ItemSellerHistory` ENABLE KEYS */;

-- Dumping structure for table test.ModHistory
CREATE TABLE IF NOT EXISTS `ModHistory` (
  `ID` int(11) NOT NULL AUTO_INCREMENT,
  `UserID` int(11) DEFAULT NULL,
  `AccountBanTime` int(11) DEFAULT NULL,
  `AccountBanLength` longtext,
  `AccountBanCategory` longtext,
  `AccountBanContent` longtext,
  `AccountBanNote` longtext,
  `AccountUnbanTime` int(11) DEFAULT NULL,
  `AccountBanAppealable` int(11) DEFAULT NULL,
  `AdministrativeNote` longtext,
  `BannedBy` longtext,
  `Status` int(11) DEFAULT '0' COMMENT '0 = default ban\n1 = appealed\n2 = escalated',
  `ChangedBy` int(11) DEFAULT '0',
  PRIMARY KEY (`ID`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- Dumping data for table test.ModHistory: ~0 rows (approximately)
/*!40000 ALTER TABLE `ModHistory` DISABLE KEYS */;
/*!40000 ALTER TABLE `ModHistory` ENABLE KEYS */;

-- Dumping structure for table test.Notification
CREATE TABLE IF NOT EXISTS `Notification` (
  `NotificationID` int(11) NOT NULL AUTO_INCREMENT,
  `PosterID` int(11) DEFAULT NULL,
  `Message` longtext,
  `Time` int(11) DEFAULT NULL,
  PRIMARY KEY (`NotificationID`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- Dumping data for table test.Notification: ~0 rows (approximately)
/*!40000 ALTER TABLE `Notification` DISABLE KEYS */;
/*!40000 ALTER TABLE `Notification` ENABLE KEYS */;

-- Dumping structure for table test.PersonnelLogs
CREATE TABLE IF NOT EXISTS `PersonnelLogs` (
  `ID` int(11) NOT NULL AUTO_INCREMENT,
  `AdminID` int(11) DEFAULT NULL,
  `Message` varchar(255) DEFAULT NULL,
  `LogTime` int(11) DEFAULT NULL,
  `IP` varchar(100) DEFAULT NULL,
  PRIMARY KEY (`ID`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- Dumping data for table test.PersonnelLogs: ~0 rows (approximately)
/*!40000 ALTER TABLE `PersonnelLogs` DISABLE KEYS */;
/*!40000 ALTER TABLE `PersonnelLogs` ENABLE KEYS */;

-- Dumping structure for table test.personnel_files
CREATE TABLE IF NOT EXISTS `personnel_files` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `user_id` int(11) DEFAULT NULL,
  `date_hired` int(11) DEFAULT NULL,
  `hiredby` varchar(45) DEFAULT NULL,
  `status` int(11) DEFAULT NULL,
  `zone` int(11) DEFAULT NULL,
  `points` int(11) DEFAULT NULL,
  `country` varchar(255) DEFAULT NULL,
  `department_name` varchar(100) DEFAULT NULL,
  `department_title` varchar(100) DEFAULT NULL,
  `first_name` varchar(45) DEFAULT NULL,
  `last_name` varchar(45) DEFAULT NULL,
  `address_line1` varchar(45) DEFAULT NULL,
  `address_line2` varchar(45) DEFAULT NULL,
  `city` varchar(45) DEFAULT NULL,
  `state` varchar(45) DEFAULT NULL,
  `zip` int(11) DEFAULT NULL,
  `country_name` varchar(45) DEFAULT NULL,
  `teamspeak` varchar(100) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- Dumping data for table test.personnel_files: ~0 rows (approximately)
/*!40000 ALTER TABLE `personnel_files` DISABLE KEYS */;
/*!40000 ALTER TABLE `personnel_files` ENABLE KEYS */;

-- Dumping structure for table test.ProfanityFilter
CREATE TABLE IF NOT EXISTS `ProfanityFilter` (
  `ID` int(11) NOT NULL AUTO_INCREMENT,
  `Word` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`ID`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- Dumping data for table test.ProfanityFilter: ~0 rows (approximately)
/*!40000 ALTER TABLE `ProfanityFilter` DISABLE KEYS */;
/*!40000 ALTER TABLE `ProfanityFilter` ENABLE KEYS */;

-- Dumping structure for table test.ProfanityWhitelist
CREATE TABLE IF NOT EXISTS `ProfanityWhitelist` (
  `ID` int(11) NOT NULL AUTO_INCREMENT,
  `Word` text,
  PRIMARY KEY (`ID`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- Dumping data for table test.ProfanityWhitelist: ~0 rows (approximately)
/*!40000 ALTER TABLE `ProfanityWhitelist` DISABLE KEYS */;
/*!40000 ALTER TABLE `ProfanityWhitelist` ENABLE KEYS */;

-- Dumping structure for table test.Reports
CREATE TABLE IF NOT EXISTS `Reports` (
  `ID` int(11) NOT NULL AUTO_INCREMENT,
  `ReporterID` int(11) DEFAULT NULL,
  `SourceID` int(11) DEFAULT NULL,
  `RelevanceID` int(11) DEFAULT NULL,
  `Category` int(11) DEFAULT NULL,
  `Comment` varchar(255) DEFAULT NULL,
  `Time` int(11) DEFAULT NULL,
  PRIMARY KEY (`ID`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- Dumping data for table test.Reports: ~0 rows (approximately)
/*!40000 ALTER TABLE `Reports` DISABLE KEYS */;
/*!40000 ALTER TABLE `Reports` ENABLE KEYS */;

-- Dumping structure for table test.SiteSetting
CREATE TABLE IF NOT EXISTS `SiteSetting` (
  `ID` int(11) NOT NULL AUTO_INCREMENT,
  `Maintenance` tinyint(4) DEFAULT '0',
  `Registration` tinyint(4) DEFAULT '1',
  `RegistrationTimer` int(11) DEFAULT '0',
  `Upgrades` tinyint(4) DEFAULT '1',
  `UpgradesTimer` int(11) DEFAULT '0',
  `CatalogPurchases` tinyint(4) DEFAULT '1',
  `StoreTimer` int(11) DEFAULT '0',
  `BannerAlertMessage` varchar(256) DEFAULT NULL,
  `BannerAlertTextColor` varchar(6) DEFAULT 'EEEEEE',
  `BannerAlertBackgroundColor` varchar(6) DEFAULT '383A3F',
  `BannerAlertFontSize` int(11) DEFAULT '16',
  `MaintenanceTimer` int(11) DEFAULT '0',
  `MaintenanceTimerVisible` int(11) DEFAULT '0',
  `AllowGroups` tinyint(4) DEFAULT '1',
  `AllowEditCharacter` tinyint(4) DEFAULT '1',
  `AllowTrades` tinyint(4) DEFAULT '1',
  `GameMaintenance` tinyint(4) DEFAULT '0',
  PRIMARY KEY (`ID`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=latin1;

-- Dumping data for table test.SiteSetting: ~0 rows (approximately)
/*!40000 ALTER TABLE `SiteSetting` DISABLE KEYS */;
REPLACE INTO `SiteSetting` (`ID`, `Maintenance`, `Registration`, `RegistrationTimer`, `Upgrades`, `UpgradesTimer`, `CatalogPurchases`, `StoreTimer`, `BannerAlertMessage`, `BannerAlertTextColor`, `BannerAlertBackgroundColor`, `BannerAlertFontSize`, `MaintenanceTimer`, `MaintenanceTimerVisible`, `AllowGroups`, `AllowEditCharacter`, `AllowTrades`, `GameMaintenance`) VALUES
	(1, 0, 1, 0, 1, 0, 1, 0, '', 'EEEEEE', '383A3F', 16, 0, 0, 1, 1, 1, 0);
/*!40000 ALTER TABLE `SiteSetting` ENABLE KEYS */;

-- Dumping structure for table test.SiteSettingAbout
CREATE TABLE IF NOT EXISTS `SiteSettingAbout` (
  `TermsOfService` text NOT NULL,
  `PrivacyPolicy` text
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- Dumping data for table test.SiteSettingAbout: ~0 rows (approximately)
/*!40000 ALTER TABLE `SiteSettingAbout` DISABLE KEYS */;
/*!40000 ALTER TABLE `SiteSettingAbout` ENABLE KEYS */;

-- Dumping structure for table test.StaticNotification
CREATE TABLE IF NOT EXISTS `StaticNotification` (
  `ID` int(11) NOT NULL AUTO_INCREMENT,
  `UserID` int(11) DEFAULT NULL,
  `Title` varchar(256) DEFAULT NULL,
  `Message` varchar(256) DEFAULT NULL,
  `Time` int(11) DEFAULT NULL,
  `Expires` int(11) DEFAULT NULL,
  `Read` int(11) DEFAULT NULL,
  PRIMARY KEY (`ID`),
  KEY `Time` (`Time`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- Dumping data for table test.StaticNotification: ~0 rows (approximately)
/*!40000 ALTER TABLE `StaticNotification` DISABLE KEYS */;
/*!40000 ALTER TABLE `StaticNotification` ENABLE KEYS */;

-- Dumping structure for table test.User
CREATE TABLE IF NOT EXISTS `User` (
  `ID` int(11) NOT NULL AUTO_INCREMENT,
  `Username` varchar(20) DEFAULT NULL,
  `Email` varchar(128) DEFAULT NULL,
  `Password` varchar(255) DEFAULT NULL,
  `AccountVerified` tinyint(4) DEFAULT '0',
  `undef1` tinyint(4) DEFAULT '0' COMMENT '',
  `undef2` tinyint(4) DEFAULT '0' COMMENT '',
  `undef3` varchar(50) DEFAULT NULL COMMENT '',
  `LastAccountVerifiedAttempt` int(11) DEFAULT '0',
  `Gender` tinyint(4) DEFAULT '0',
  `Avatar` tinyint(4) DEFAULT '0',
  `BirthdateMonth` int(11) DEFAULT NULL,
  `BirthdateDay` int(11) DEFAULT NULL,
  `BirthdateYear` int(11) DEFAULT NULL,
  `TimeRegister` int(11) DEFAULT NULL,
  `TimeLastSeen` int(11) DEFAULT NULL,
  `LastIP` varchar(60) DEFAULT NULL,
  `PublicKey` varchar(25) DEFAULT NULL,
  `AvatarURL` varchar(128) DEFAULT NULL,
  `ThumbnailURL` varchar(128) DEFAULT NULL,
  `Admin` tinyint(4) DEFAULT '0',
  `BetaTester` tinyint(4) DEFAULT '0',
  `About` varchar(1500) DEFAULT NULL,
  `CurrencyCoins` int(11) unsigned DEFAULT '0',
  `CurrencyCredits` int(11) unsigned DEFAULT '0',
  `UserFlood` int(11) DEFAULT '0',
  `NextFreeCoinPay` int(11) DEFAULT '0',
  `NextUpgradeCoinPay` int(11) DEFAULT '0',
  `NumMessages` int(11) unsigned DEFAULT '0',
  `NumChats` int(11) unsigned DEFAULT '0',
  `NumFriendRequests` int(11) unsigned DEFAULT '0',
  `NumFriends` int(11) unsigned DEFAULT '0',
  `NumTradeRequests` int(11) unsigned DEFAULT '0',
  `NumNotifications` int(11) unsigned DEFAULT '0',
  `NumForumPosts` int(11) unsigned DEFAULT '0',
  `NumForumBookmarks` int(11) unsigned DEFAULT '0',
  `NumForumDrafts` int(11) unsigned DEFAULT '0',
  `NumEquippedHats` int(11) unsigned DEFAULT '0',
  `NumWallPosts` int(11) unsigned DEFAULT '0',
  `NumGroups` int(11) unsigned DEFAULT '0',
  `ForumEXP` int(11) unsigned DEFAULT '0',
  `ForumLevel` int(11) unsigned DEFAULT '1',
  `HexHead` int(11) DEFAULT '3',
  `HexLeftArm` int(11) DEFAULT '3',
  `HexTorso` int(11) DEFAULT '2',
  `HexRightArm` int(11) DEFAULT '3',
  `HexLeftLeg` int(11) DEFAULT '3',
  `HexRightLeg` int(11) DEFAULT '3',
  `AccountRestricted` tinyint(4) DEFAULT '0',
  `PersonalStatus` varchar(128) DEFAULT NULL,
  `PrivateMessageSettings` tinyint(4) DEFAULT '0',
  `FriendRequestSettings` tinyint(4) DEFAULT '0',
  `TradeSettings` tinyint(4) DEFAULT '0',
  `PostWallSettings` tinyint(4) DEFAULT '0',
  `ViewWallSettings` tinyint(4) DEFAULT '0',
  `NotificationSettingsChats` tinyint(4) DEFAULT '1',
  `NotificationSettingsIncomingTrades` tinyint(4) DEFAULT '1',
  `NotificationSettingsSellItem` tinyint(4) DEFAULT '1',
  `NotificationSettingsBlog` tinyint(4) DEFAULT '1',
  `NotificationSettingsFriendRequests` tinyint(4) DEFAULT '1',
  `NotificationSettingsGroups` tinyint(4) DEFAULT '1',
  `NotificationSettingsWall` tinyint(4) DEFAULT '1',
  `CountryRestrict` tinyint(4) DEFAULT '1',
  `EmailNotifications` tinyint(4) DEFAULT '1',
  `Country` varchar(6) DEFAULT '0',
  `VIP` tinyint(4) DEFAULT '0',
  `VIP_Recurring` tinyint(4) DEFAULT '0',
  `VIP_Expires` int(11) DEFAULT '0',
  `TotalEarningsCount` int(11) DEFAULT '0',
  `TotalEarningsRank` int(11) DEFAULT '0',
  `SalesCount` int(11) DEFAULT '0',
  `EarningsCount` int(11) DEFAULT '0',
  `ItemCount` int(11) DEFAULT '0',
  `UpgradesCount` int(11) DEFAULT '0',
  `StripeKey` varchar(128) DEFAULT NULL,
  `NextEmailChange` int(11) DEFAULT '0',
  `AvatarOrientation` tinyint(4) DEFAULT '0' COMMENT '0 - Right\n1 - Left',
  `FavoriteGroup` int(11) DEFAULT '0',
  `DiscordId` varchar(20) DEFAULT '0',
  `ChatId` varchar(20) DEFAULT NULL,
  `InGame` tinyint(4) DEFAULT '0',
  `InGameId` int(11) DEFAULT NULL,
  `InGameTime` int(11) DEFAULT '0',
  `NumGameVisits` int(11) DEFAULT '0',
  PRIMARY KEY (`ID`),
  KEY `User_Admin_Index` (`Admin`),
  KEY `User_BetaTester_Index` (`BetaTester`),
  KEY `User_AccountRestricted` (`AccountRestricted`),
  KEY `User_LastIP_Index` (`LastIP`),
  KEY `User_Username_Index` (`Username`),
  KEY `User_TimeRegister_Index` (`TimeRegister`),
  KEY `User_DiscordId_Index` (`DiscordId`),
  KEY `User_ChatId_Index` (`ChatId`),
  KEY `User_TimeLastSeen_Index` (`TimeLastSeen`),
  KEY `User_InGameId_FK_idx` (`InGameId`),
  KEY `User_InGame_Index` (`InGame`),
  KEY `User_AccountVerified_Index` (`AccountVerified`),
  KEY `User_EmailAccountVerified_Index` (`Email`,`AccountVerified`),
  KEY `User_VIP_Index` (`VIP`),
  FULLTEXT KEY `User_Username_FullText` (`Username`),
  CONSTRAINT `User_InGameId_FK` FOREIGN KEY (`InGameId`) REFERENCES `game`.`UserGame` (`ID`) ON DELETE NO ACTION ON UPDATE NO ACTION
) ENGINE=InnoDB AUTO_INCREMENT=172486 DEFAULT CHARSET=latin1;

-- Dumping data for table test.User: ~6 rows (approximately)
/*!40000 ALTER TABLE `User` DISABLE KEYS */;
REPLACE INTO `User` (`ID`, `Username`, `Email`, `Password`, `AccountVerified`, `unk1`, `unk2`, `unk3`, `LastAccountVerifiedAttempt`, `Gender`, `Avatar`, `BirthdateMonth`, `BirthdateDay`, `BirthdateYear`, `TimeRegister`, `TimeLastSeen`, `LastIP`, `PublicKey`, `AvatarURL`, `ThumbnailURL`, `Admin`, `BetaTester`, `About`, `CurrencyCoins`, `CurrencyCredits`, `UserFlood`, `NextFreeCoinPay`, `NextUpgradeCoinPay`, `NumMessages`, `NumChats`, `NumFriendRequests`, `NumFriends`, `NumTradeRequests`, `NumNotifications`, `NumForumPosts`, `NumForumBookmarks`, `NumForumDrafts`, `NumEquippedHats`, `NumWallPosts`, `NumGroups`, `ForumEXP`, `ForumLevel`, `HexHead`, `HexLeftArm`, `HexTorso`, `HexRightArm`, `HexLeftLeg`, `HexRightLeg`, `AccountRestricted`, `PersonalStatus`, `PrivateMessageSettings`, `FriendRequestSettings`, `TradeSettings`, `PostWallSettings`, `ViewWallSettings`, `NotificationSettingsChats`, `NotificationSettingsIncomingTrades`, `NotificationSettingsSellItem`, `NotificationSettingsBlog`, `NotificationSettingsFriendRequests`, `NotificationSettingsGroups`, `NotificationSettingsWall`, `CountryRestrict`, `EmailNotifications`, `Country`, `VIP`, `VIP_Recurring`, `VIP_Expires`, `TotalEarningsCount`, `TotalEarningsRank`, `SalesCount`, `EarningsCount`, `ItemCount`, `UpgradesCount`, `StripeKey`, `NextEmailChange`, `AvatarOrientation`, `FavoriteGroup`, `DiscordId`, `ChatId`, `InGame`, `InGameId`, `InGameTime`, `NumGameVisits`) VALUES
	(172480, 'Isaac', NULL, '', 0, 0, 0, NULL, 0, 0, 0, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 0, 0, NULL, 99999, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 1, 3, 3, 2, 3, 3, 3, 0, NULL, 0, 0, 0, 0, 0, 1, 1, 1, 1, 1, 1, 1, 1, 1, '0', 0, 0, 0, 0, 0, 0, 0, 0, 0, NULL, 0, 0, 0, '0', NULL, 0, NULL, 0, 0),
	(172481, '', '', '', 0, 1, 0, 'YIESTK3IEDJHRDVD', 0, 0, 0, NULL, NULL, NULL, 1516551980, 1517711558, '192.168.2.12', NULL, '8ca17bec-0320-4293-90e5-dfc5b8690156', NULL, 0, 0, NULL, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 1, 3, 3, 2, 3, 3, 3, 0, NULL, 0, 0, 0, 0, 0, 1, 1, 1, 1, 1, 1, 1, 1, 1, '0', 0, 0, 0, 0, 0, 0, 0, 0, 0, NULL, 0, 0, 0, '0', NULL, 0, NULL, 0, 0),
	(172482, '', '', '', 0, 0, 0, NULL, 0, 0, 0, NULL, NULL, NULL, 1516552083, 1516807192, '127.0.0.1', NULL, '8ca17bec-0320-4293-90e5-dfc5b8690156', NULL, 0, 0, NULL, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 1, 3, 3, 2, 3, 3, 3, 0, NULL, 0, 0, 0, 0, 0, 1, 1, 1, 1, 1, 1, 1, 1, 1, '0', 0, 0, 0, 0, 0, 0, 0, 0, 0, NULL, 0, 0, 0, '0', NULL, 0, NULL, 0, 0),
	(172483, '', '', '', 0, 0, 0, NULL, 0, 0, 0, NULL, NULL, NULL, 1516808016, 1516808016, '127.0.0.1', NULL, '8ca17bec-0320-4293-90e5-dfc5b8690156', NULL, 0, 0, NULL, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 1, 3, 3, 2, 3, 3, 3, 0, NULL, 0, 0, 0, 0, 0, 1, 1, 1, 1, 1, 1, 1, 1, 1, '0', 0, 0, 0, 0, 0, 0, 0, 0, 0, NULL, 0, 0, 0, '0', NULL, 0, NULL, 0, 0),
	(172484, '', '', '', 0, 0, 1, '2GF7IW2HZJFS43BD', 0, 0, 0, NULL, NULL, NULL, 1517303999, 1517353200, '127.0.0.1', NULL, '8ca17bec-0320-4293-90e5-dfc5b8690156', NULL, 0, 0, NULL, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 1, 3, 3, 2, 3, 3, 3, 0, NULL, 0, 0, 0, 0, 0, 1, 1, 1, 1, 1, 1, 1, 1, 1, '0', 0, 0, 0, 0, 0, 0, 0, 0, 0, NULL, 0, 0, 0, '0', NULL, 0, NULL, 0, 0),
	(172485, '', '', '', 0, 0, 1, 'UWZ2WAOZCOINQD7L', 0, 0, 0, NULL, NULL, NULL, 1517654659, 1518112024, '127.0.0.1', NULL, '8ca17bec-0320-4293-90e5-dfc5b8690156', NULL, 0, 0, NULL, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 1, 3, 3, 2, 3, 3, 3, 0, NULL, 0, 0, 0, 0, 0, 1, 1, 1, 1, 1, 1, 1, 1, 1, '0', 0, 0, 0, 0, 0, 0, 0, 0, 0, NULL, 0, 0, 0, '0', NULL, 0, NULL, 0, 0);
/*!40000 ALTER TABLE `User` ENABLE KEYS */;

-- Dumping structure for table test.UserAccountLock
CREATE TABLE IF NOT EXISTS `UserAccountLock` (
  `ID` int(11) NOT NULL AUTO_INCREMENT,
  `UserID` int(11) DEFAULT '0',
  `Reason` longtext,
  `AdminID` int(11) DEFAULT '0',
  PRIMARY KEY (`ID`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- Dumping data for table test.UserAccountLock: ~0 rows (approximately)
/*!40000 ALTER TABLE `UserAccountLock` DISABLE KEYS */;
/*!40000 ALTER TABLE `UserAccountLock` ENABLE KEYS */;

-- Dumping structure for table test.UserActionLog
CREATE TABLE IF NOT EXISTS `UserActionLog` (
  `ID` int(11) NOT NULL AUTO_INCREMENT,
  `UserID` int(11) DEFAULT NULL,
  `Action` text,
  `TimeLog` int(11) DEFAULT NULL,
  `IP` varchar(60) DEFAULT NULL,
  `ArchiveID` int(11) DEFAULT '0',
  PRIMARY KEY (`ID`),
  KEY `UserActionLog_UserID_FK_idx` (`UserID`),
  CONSTRAINT `UserActionLog_UserID_FK` FOREIGN KEY (`UserID`) REFERENCES `User` (`ID`) ON DELETE NO ACTION ON UPDATE NO ACTION
) ENGINE=InnoDB AUTO_INCREMENT=614184 DEFAULT CHARSET=latin1;

-- Dumping data for table test.UserActionLog: ~74 rows (approximately)
/*!40000 ALTER TABLE `UserActionLog` DISABLE KEYS */;
REPLACE INTO `UserActionLog` (`ID`, `UserID`, `Action`, `TimeLog`, `IP`, `ArchiveID`) VALUES
	(614103, 172480, 'Logged in', 1515296618, '127.0.0.1', 0),
	(614104, 172480, 'Logged in', 1515296703, '127.0.0.1', 0),
	(614105, 172481, 'Logged in', 1516552031, '127.0.0.1', 0),
	(614106, 172481, 'Logged in', 1516552442, '127.0.0.1', 0),
	(614107, 172481, 'Logged in', 1516554759, '127.0.0.1', 0),
	(614108, 172481, 'Logged in', 1516554781, '127.0.0.1', 0),
	(614109, 172481, 'Logged in', 1516554843, '127.0.0.1', 0),
	(614110, 172481, 'Logged in', 1516555001, '127.0.0.1', 0),
	(614111, 172481, 'Logged in', 1516556641, '127.0.0.1', 0),
	(614112, 172481, 'Logged in', 1516556658, '127.0.0.1', 0),
	(614113, 172481, 'Logged in', 1516556779, '127.0.0.1', 0),
	(614114, 172481, 'Logged in', 1516556879, '127.0.0.1', 0),
	(614115, 172481, 'Logged in', 1516556905, '127.0.0.1', 0),
	(614116, 172481, 'Logged in', 1516557585, '127.0.0.1', 0),
	(614117, 172481, 'Logged in', 1516557685, '127.0.0.1', 0),
	(614118, 172481, 'Logged in', 1516558437, '127.0.0.1', 0),
	(614119, 172481, 'Logged in', 1516639729, '127.0.0.1', 0),
	(614120, 172481, 'Logged in', 1516644394, '127.0.0.1', 0),
	(614121, 172481, 'Logged in', 1516650771, '127.0.0.1', 0),
	(614122, 172481, 'Logged in', 1516697449, '127.0.0.1', 0),
	(614123, 172481, 'Logged in', 1516715952, '127.0.0.1', 0),
	(614124, 172481, 'Logged in', 1516718524, '127.0.0.1', 0),
	(614125, 172481, 'Logged in', 1516718536, '127.0.0.1', 0),
	(614126, 172481, 'Logged in', 1516741094, '127.0.0.1', 0),
	(614127, 172481, 'Logged in', 1516805829, '127.0.0.1', 0),
	(614128, 172481, 'Logged in', 1516806885, '127.0.0.1', 0),
	(614129, 172481, 'Logged in', 1516806983, '127.0.0.1', 0),
	(614130, 172482, 'Logged in', 1516807192, '127.0.0.1', 0),
	(614131, 172481, 'Logged in', 1516807790, '127.0.0.1', 0),
	(614132, 172481, 'Logged in', 1516807986, '127.0.0.1', 0),
	(614133, 172481, 'Logged in', 1516818199, '127.0.0.1', 0),
	(614134, 172481, 'Logged in', 1516831915, '127.0.0.1', 0),
	(614135, 172481, 'Logged in', 1516841067, '127.0.0.1', 0),
	(614136, 172481, 'Logged in', 1516843562, '127.0.0.1', 0),
	(614137, 172481, 'Logged in', 1516843775, '127.0.0.1', 0),
	(614138, 172481, 'Logged in', 1516844721, '127.0.0.1', 0),
	(614139, 172481, 'Logged in', 1516844830, '127.0.0.1', 0),
	(614140, 172481, 'Logged in', 1516845728, '127.0.0.1', 0),
	(614141, 172481, 'Logged in', 1516864968, '127.0.0.1', 0),
	(614142, 172481, 'Logged in', 1517250232, '127.0.0.1', 0),
	(614143, 172481, 'Logged in', 1517250361, '127.0.0.1', 0),
	(614144, 172481, 'Logged in', 1517252255, '127.0.0.1', 0),
	(614145, 172481, 'Logged in', 1517258199, '127.0.0.1', 0),
	(614146, 172481, 'Logged in', 1517258274, '127.0.0.1', 0),
	(614147, 172481, 'Logged in', 1517258755, '127.0.0.1', 0),
	(614148, 172481, 'Logged in', 1517259256, '127.0.0.1', 0),
	(614149, 172481, 'Logged in', 1517303937, '127.0.0.1', 0),
	(614150, 172484, 'Logged in', 1517304594, '127.0.0.1', 0),
	(614151, 172484, 'Logged in', 1517305113, '127.0.0.1', 0),
	(614152, 172484, 'Logged in', 1517307695, '127.0.0.1', 0),
	(614153, 172484, 'Logged in', 1517308439, '127.0.0.1', 0),
	(614154, 172484, 'Logged in', 1517308874, '127.0.0.1', 0),
	(614155, 172484, 'Logged in', 1517341539, '127.0.0.1', 0),
	(614156, 172484, 'Logged in', 1517352987, '127.0.0.1', 0),
	(614157, 172481, 'Logged in', 1517563734, '127.0.0.1', 0),
	(614158, 172481, 'Logged in', 1517653262, '127.0.0.1', 0),
	(614159, 172481, 'Logged in', 1517653915, '127.0.0.1', 0),
	(614160, 172481, 'Logged in', 1517710019, '127.0.0.1', 0),
	(614161, 172481, 'Logged in', 1517711070, '192.168.2.12', 0),
	(614162, 172481, 'Logged in', 1517711192, '192.168.2.12', 0),
	(614163, 172485, 'Logged in', 1517711566, '192.168.2.12', 0),
	(614164, 172485, 'Logged in', 1517711939, '192.168.2.12', 0),
	(614165, 172485, 'Logged in', 1517718067, '127.0.0.1', 0),
	(614166, 172485, 'Logged in', 1517718199, '127.0.0.1', 0),
	(614167, 172485, 'Logged in', 1518026291, '127.0.0.1', 0),
	(614168, 172485, 'Logged in', 1518103420, '127.0.0.1', 0),
	(614169, 172485, 'Logged in', 1518105798, '127.0.0.1', 0),
	(614170, 172485, 'Logged in', 1518106263, '127.0.0.1', 0),
	(614171, 172485, 'Logged in', 1518107130, '127.0.0.1', 0),
	(614172, 172485, 'Logged in', 1518107738, '127.0.0.1', 0),
	(614173, 172485, 'Logged in', 1518108227, '127.0.0.1', 0),
	(614174, 172485, 'Logged in', 1518108318, '127.0.0.1', 0),
	(614175, 172485, 'Logged in', 1518108777, '127.0.0.1', 0),
	(614176, 172485, 'Logged in', 1518109033, '127.0.0.1', 0),
	(614177, 172485, 'Logged in', 1518109075, '127.0.0.1', 0),
	(614178, 172485, 'Logged in', 1518109234, '127.0.0.1', 0),
	(614179, 172485, 'Logged in', 1518109915, '127.0.0.1', 0),
	(614180, 172485, 'Logged in', 1518109961, '127.0.0.1', 0),
	(614181, 172485, 'Logged in', 1518110153, '127.0.0.1', 0),
	(614182, 172485, 'Logged in', 1518111040, '127.0.0.1', 0),
	(614183, 172485, 'Logged in', 1518112024, '127.0.0.1', 0);
/*!40000 ALTER TABLE `UserActionLog` ENABLE KEYS */;

-- Dumping structure for table test.UserAdminLogs
CREATE TABLE IF NOT EXISTS `UserAdminLogs` (
  `ID` int(11) NOT NULL AUTO_INCREMENT,
  `AdminID` int(11) DEFAULT NULL,
  `Message` longtext,
  `LogTime` int(11) DEFAULT NULL,
  `IP` varchar(100) DEFAULT NULL,
  PRIMARY KEY (`ID`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- Dumping data for table test.UserAdminLogs: ~0 rows (approximately)
/*!40000 ALTER TABLE `UserAdminLogs` DISABLE KEYS */;
/*!40000 ALTER TABLE `UserAdminLogs` ENABLE KEYS */;

-- Dumping structure for table test.UserBadge
CREATE TABLE IF NOT EXISTS `UserBadge` (
  `ID` int(11) NOT NULL AUTO_INCREMENT,
  `UserID` int(11) NOT NULL DEFAULT '0',
  `AchievementID` int(11) NOT NULL DEFAULT '0',
  PRIMARY KEY (`ID`),
  UNIQUE KEY `UserBadge_Unique` (`UserID`,`AchievementID`),
  KEY `UserBadge_AchievementID_FK_idx` (`AchievementID`),
  CONSTRAINT `UserBadge_AchievementID_FK` FOREIGN KEY (`AchievementID`) REFERENCES `Achievement` (`ID`) ON DELETE NO ACTION ON UPDATE NO ACTION,
  CONSTRAINT `UserBadge_UserID_FK` FOREIGN KEY (`UserID`) REFERENCES `User` (`ID`) ON DELETE NO ACTION ON UPDATE NO ACTION
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- Dumping data for table test.UserBadge: ~0 rows (approximately)
/*!40000 ALTER TABLE `UserBadge` DISABLE KEYS */;
/*!40000 ALTER TABLE `UserBadge` ENABLE KEYS */;

-- Dumping structure for table test.UserBanHistory
CREATE TABLE IF NOT EXISTS `UserBanHistory` (
  `ID` int(11) NOT NULL AUTO_INCREMENT,
  `UserID` int(11) DEFAULT NULL,
  `AdminID` int(11) DEFAULT NULL,
  `TimeBan` int(11) DEFAULT NULL,
  `TimeUnban` int(11) DEFAULT NULL,
  `BanCategory` int(11) DEFAULT NULL,
  `Content` text,
  `ModNote` varchar(128) DEFAULT NULL,
  `AdminNote` varchar(128) DEFAULT NULL,
  `Status` int(11) DEFAULT '0' COMMENT '0 - Active\n1 - Reviewed By User\n2 - Overturned by Administrator',
  `UnbannedBy` int(11) DEFAULT NULL,
  PRIMARY KEY (`ID`),
  KEY `UserBanHistory_UserID_FK_idx` (`UserID`),
  KEY `UserBanHistory_AdminID_FK_idx` (`AdminID`),
  KEY `UserBanHistory_TimeBan_Index` (`TimeBan`),
  KEY `UserBanHistory_TimeUnban_Index` (`TimeUnban`),
  KEY `UserBanHistory_UnbannedBy_FK_idx` (`UnbannedBy`),
  CONSTRAINT `UserBanHistory_AdminID_FK` FOREIGN KEY (`AdminID`) REFERENCES `User` (`ID`) ON DELETE NO ACTION ON UPDATE NO ACTION,
  CONSTRAINT `UserBanHistory_UnbannedBy_FK` FOREIGN KEY (`UnbannedBy`) REFERENCES `User` (`ID`) ON DELETE NO ACTION ON UPDATE NO ACTION,
  CONSTRAINT `UserBanHistory_UserID_FK` FOREIGN KEY (`UserID`) REFERENCES `User` (`ID`) ON DELETE NO ACTION ON UPDATE NO ACTION
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- Dumping data for table test.UserBanHistory: ~0 rows (approximately)
/*!40000 ALTER TABLE `UserBanHistory` DISABLE KEYS */;
/*!40000 ALTER TABLE `UserBanHistory` ENABLE KEYS */;

-- Dumping structure for table test.UserBlocked
CREATE TABLE IF NOT EXISTS `UserBlocked` (
  `ID` int(11) NOT NULL AUTO_INCREMENT,
  `RequesterID` int(11) DEFAULT NULL,
  `BlockedID` int(11) DEFAULT NULL,
  `TimeBlocked` int(11) DEFAULT NULL,
  PRIMARY KEY (`ID`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- Dumping data for table test.UserBlocked: ~0 rows (approximately)
/*!40000 ALTER TABLE `UserBlocked` DISABLE KEYS */;
/*!40000 ALTER TABLE `UserBlocked` ENABLE KEYS */;

-- Dumping structure for table test.UserChat
CREATE TABLE IF NOT EXISTS `UserChat` (
  `ID` int(11) NOT NULL AUTO_INCREMENT,
  `SenderID` int(11) DEFAULT NULL,
  `ReceiverID` int(11) DEFAULT NULL,
  `TimeChat` int(11) DEFAULT NULL,
  `TimeRead` int(11) DEFAULT '0',
  `Message` varchar(256) DEFAULT NULL,
  PRIMARY KEY (`ID`),
  KEY `UserChat_SenderID_FK_idx` (`SenderID`),
  KEY `UserChat_ReceiverID_FK_idx` (`ReceiverID`),
  KEY `UserChat_TimeChat_Index` (`TimeChat`),
  KEY `UserChat_TimeRead_Index` (`TimeRead`),
  KEY `UserChat_SenderReceiverID_Index` (`SenderID`,`ReceiverID`),
  CONSTRAINT `UserChat_ReceiverID_FK` FOREIGN KEY (`ReceiverID`) REFERENCES `User` (`ID`) ON DELETE NO ACTION ON UPDATE NO ACTION,
  CONSTRAINT `UserChat_SenderID_FK` FOREIGN KEY (`SenderID`) REFERENCES `User` (`ID`) ON DELETE NO ACTION ON UPDATE NO ACTION
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- Dumping data for table test.UserChat: ~0 rows (approximately)
/*!40000 ALTER TABLE `UserChat` DISABLE KEYS */;
/*!40000 ALTER TABLE `UserChat` ENABLE KEYS */;

-- Dumping structure for table test.UserChatGroup
CREATE TABLE IF NOT EXISTS `UserChatGroup` (
  `ID` int(11) NOT NULL AUTO_INCREMENT,
  `Name` varchar(40) DEFAULT NULL,
  `OwnerID` int(11) DEFAULT NULL,
  `MemberCount` tinyint(4) DEFAULT '0',
  `InviteCode` varchar(10) DEFAULT NULL,
  `GroupImage` varchar(128) DEFAULT NULL,
  `ImageStatus` varchar(128) DEFAULT '1',
  `TimeCreate` int(11) DEFAULT '0',
  `TimeNameUpdate` int(11) DEFAULT '0',
  `TimeImageUpdate` int(11) DEFAULT '0',
  PRIMARY KEY (`ID`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- Dumping data for table test.UserChatGroup: ~0 rows (approximately)
/*!40000 ALTER TABLE `UserChatGroup` DISABLE KEYS */;
/*!40000 ALTER TABLE `UserChatGroup` ENABLE KEYS */;

-- Dumping structure for table test.UserChatGroupMember
CREATE TABLE IF NOT EXISTS `UserChatGroupMember` (
  `ID` int(11) NOT NULL AUTO_INCREMENT,
  `ChatGroupID` int(11) DEFAULT NULL,
  `UserID` int(11) DEFAULT NULL,
  `Role` tinyint(4) DEFAULT '0' COMMENT '0 - User\n1 - Moderator\n2 - Owner',
  `UnreadMessageCount` int(11) DEFAULT '0',
  `TimeLastAction` int(11) DEFAULT '0',
  PRIMARY KEY (`ID`),
  UNIQUE KEY `UserChatGroupMember_Unique` (`ChatGroupID`,`UserID`),
  KEY `UserChatGroupMember_ChatGroupID_FK_idx` (`ChatGroupID`),
  KEY `UserChatGroupMember_UserID_FK_idx` (`UserID`),
  KEY `UserChatGroupMember_Role_Index` (`Role`),
  CONSTRAINT `UserChatGroupMember_ChatGroupID_FK` FOREIGN KEY (`ChatGroupID`) REFERENCES `UserChatGroup` (`ID`) ON DELETE NO ACTION ON UPDATE NO ACTION,
  CONSTRAINT `UserChatGroupMember_UserID_FK` FOREIGN KEY (`UserID`) REFERENCES `User` (`ID`) ON DELETE NO ACTION ON UPDATE NO ACTION
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- Dumping data for table test.UserChatGroupMember: ~0 rows (approximately)
/*!40000 ALTER TABLE `UserChatGroupMember` DISABLE KEYS */;
/*!40000 ALTER TABLE `UserChatGroupMember` ENABLE KEYS */;

-- Dumping structure for table test.UserChatGroupMessage
CREATE TABLE IF NOT EXISTS `UserChatGroupMessage` (
  `ID` int(11) NOT NULL AUTO_INCREMENT,
  `ChatGroupID` int(11) DEFAULT NULL,
  `UserID` int(11) DEFAULT NULL,
  `TimeChat` int(11) DEFAULT NULL,
  `Message` varchar(256) DEFAULT NULL,
  PRIMARY KEY (`ID`),
  KEY `UserChatGroupMessage_TimeChat_Index` (`TimeChat`),
  KEY `UserChatGroupMessage_ChatGroupID_FK_idx` (`ChatGroupID`),
  KEY `UserChatGroupMessage_UserID_FK_idx` (`UserID`),
  CONSTRAINT `UserChatGroupMessage_ChatGroupID_FK` FOREIGN KEY (`ChatGroupID`) REFERENCES `UserChatGroup` (`ID`) ON DELETE NO ACTION ON UPDATE NO ACTION,
  CONSTRAINT `UserChatGroupMessage_UserID_FK` FOREIGN KEY (`UserID`) REFERENCES `User` (`ID`) ON DELETE NO ACTION ON UPDATE NO ACTION
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- Dumping data for table test.UserChatGroupMessage: ~0 rows (approximately)
/*!40000 ALTER TABLE `UserChatGroupMessage` DISABLE KEYS */;
/*!40000 ALTER TABLE `UserChatGroupMessage` ENABLE KEYS */;

-- Dumping structure for table test.UserColor
CREATE TABLE IF NOT EXISTS `UserColor` (
  `ID` int(11) NOT NULL AUTO_INCREMENT,
  `HexColor` varchar(6) DEFAULT NULL,
  `R` varchar(5) DEFAULT NULL,
  `G` varchar(5) DEFAULT NULL,
  `B` varchar(5) DEFAULT NULL,
  PRIMARY KEY (`ID`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- Dumping data for table test.UserColor: ~0 rows (approximately)
/*!40000 ALTER TABLE `UserColor` DISABLE KEYS */;
/*!40000 ALTER TABLE `UserColor` ENABLE KEYS */;

-- Dumping structure for table test.UserDailyEarning
CREATE TABLE IF NOT EXISTS `UserDailyEarning` (
  `ID` int(11) NOT NULL AUTO_INCREMENT,
  `UserID` int(11) DEFAULT NULL,
  `Coins` int(11) DEFAULT NULL,
  `TimeStart` int(11) DEFAULT NULL,
  `TimeEnd` int(11) DEFAULT NULL,
  `TransactionsCount` int(11) DEFAULT '0',
  `Status` int(11) DEFAULT '0',
  PRIMARY KEY (`ID`),
  KEY `UserDailyEarning_UserID_FK_idx` (`UserID`),
  KEY `UserDailyEarning_TimeStart_Index` (`TimeStart`),
  KEY `UserDailyEarning_TimeEnd_Index` (`TimeEnd`),
  KEY `UserDailyEarning_Status_Index` (`Status`),
  CONSTRAINT `UserDailyEarning_UserID_FK` FOREIGN KEY (`UserID`) REFERENCES `User` (`ID`) ON DELETE NO ACTION ON UPDATE NO ACTION
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- Dumping data for table test.UserDailyEarning: ~0 rows (approximately)
/*!40000 ALTER TABLE `UserDailyEarning` DISABLE KEYS */;
/*!40000 ALTER TABLE `UserDailyEarning` ENABLE KEYS */;

-- Dumping structure for table test.UserDiscordVerify
CREATE TABLE IF NOT EXISTS `UserDiscordVerify` (
  `ID` int(11) NOT NULL AUTO_INCREMENT,
  `UserID` int(11) DEFAULT NULL,
  `Key` varchar(24) DEFAULT NULL,
  `TimeInitiated` int(11) DEFAULT NULL,
  PRIMARY KEY (`ID`),
  KEY `UserDiscordVerify_UserID_FK_idx` (`UserID`),
  KEY `UserDiscordVerify_Key_Index` (`Key`),
  CONSTRAINT `UserDiscordVerify_UserID_FK` FOREIGN KEY (`UserID`) REFERENCES `User` (`ID`) ON DELETE NO ACTION ON UPDATE NO ACTION
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- Dumping data for table test.UserDiscordVerify: ~0 rows (approximately)
/*!40000 ALTER TABLE `UserDiscordVerify` DISABLE KEYS */;
/*!40000 ALTER TABLE `UserDiscordVerify` ENABLE KEYS */;

-- Dumping structure for table test.UserEmailChange
CREATE TABLE IF NOT EXISTS `UserEmailChange` (
  `ID` int(11) NOT NULL AUTO_INCREMENT,
  `UserID` int(11) DEFAULT NULL,
  `OldEmail` varchar(128) DEFAULT NULL,
  `NewEmail` varchar(128) DEFAULT NULL,
  `OldWasVerified` int(11) DEFAULT NULL,
  `ChangeKey` varchar(20) DEFAULT NULL,
  `TimeChange` int(11) DEFAULT NULL,
  `Changed` int(11) DEFAULT '0',
  PRIMARY KEY (`ID`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- Dumping data for table test.UserEmailChange: ~0 rows (approximately)
/*!40000 ALTER TABLE `UserEmailChange` DISABLE KEYS */;
/*!40000 ALTER TABLE `UserEmailChange` ENABLE KEYS */;

-- Dumping structure for table test.UserEmojiHistory
CREATE TABLE IF NOT EXISTS `UserEmojiHistory` (
  `ID` int(11) NOT NULL AUTO_INCREMENT,
  `UserID` int(11) DEFAULT NULL,
  `Name` varchar(50) DEFAULT NULL,
  `TimeLastUsed` int(11) DEFAULT NULL,
  PRIMARY KEY (`ID`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- Dumping data for table test.UserEmojiHistory: ~0 rows (approximately)
/*!40000 ALTER TABLE `UserEmojiHistory` DISABLE KEYS */;
/*!40000 ALTER TABLE `UserEmojiHistory` ENABLE KEYS */;

-- Dumping structure for table test.UserEquipped
CREATE TABLE IF NOT EXISTS `UserEquipped` (
  `ID` int(11) NOT NULL AUTO_INCREMENT,
  `UserID` int(11) DEFAULT NULL,
  `ItemType` int(11) DEFAULT NULL,
  `InventoryID` int(11) DEFAULT NULL,
  PRIMARY KEY (`ID`),
  KEY `UserEquipped_UserID_FK_idx` (`UserID`),
  KEY `UserEquipped_ItemType_Index` (`ItemType`),
  KEY `UserEquipped_InventoryID_FK_idx` (`InventoryID`),
  CONSTRAINT `UserEquipped_InventoryID_FK` FOREIGN KEY (`InventoryID`) REFERENCES `UserInventory` (`ID`) ON DELETE NO ACTION ON UPDATE NO ACTION,
  CONSTRAINT `UserEquipped_UserID_FK` FOREIGN KEY (`UserID`) REFERENCES `User` (`ID`) ON DELETE NO ACTION ON UPDATE NO ACTION
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- Dumping data for table test.UserEquipped: ~0 rows (approximately)
/*!40000 ALTER TABLE `UserEquipped` DISABLE KEYS */;
/*!40000 ALTER TABLE `UserEquipped` ENABLE KEYS */;

-- Dumping structure for table test.UserGroup
CREATE TABLE IF NOT EXISTS `UserGroup` (
  `ID` int(11) NOT NULL AUTO_INCREMENT,
  `GroupCategory` tinyint(4) DEFAULT '0',
  `Name` varchar(60) DEFAULT NULL,
  `SEOName` varchar(128) DEFAULT NULL,
  `Description` text,
  `OwnerID` int(11) DEFAULT NULL,
  `OwnerType` tinyint(4) DEFAULT '0',
  `TimeCreate` int(11) DEFAULT NULL,
  `LogoImage` varchar(128) DEFAULT NULL,
  `LogoStatus` tinyint(4) DEFAULT '0',
  `CoinsVault` int(11) DEFAULT '0',
  `VaultDisplay` int(11) DEFAULT '0',
  `JoinType` tinyint(4) DEFAULT '0',
  `NonMemberTab` int(11) DEFAULT '1',
  `MemberTab` int(11) DEFAULT '1',
  `MemberCount` int(11) DEFAULT '1',
  `WallCount` int(11) DEFAULT '0',
  `DivisionCount` int(11) DEFAULT '0',
  `StoreCount` int(11) DEFAULT '0',
  `JoinRequestCount` int(11) DEFAULT '0',
  `OutboundRequestCount` int(11) DEFAULT '0',
  `TotalEarningsCount` int(11) DEFAULT '0',
  `TotalEarningsRank` int(11) DEFAULT '0',
  `SalesCount` int(11) DEFAULT '0',
  `EarningsCount` int(11) DEFAULT '0',
  `IsVerified` tinyint(4) DEFAULT '0',
  `IsDisabled` tinyint(4) DEFAULT '0',
  PRIMARY KEY (`ID`),
  UNIQUE KEY `UserGroup_Name_Unique` (`Name`),
  KEY `UserGroup_GroupCategory_Index` (`GroupCategory`),
  KEY `UserGroup_Name_Index` (`Name`),
  KEY `UserGroup_LogoStatus_Index` (`LogoStatus`),
  KEY `UserGroup_OwnerID_FK_idx` (`OwnerID`),
  KEY `UserGroup_OwnerType_Index` (`OwnerType`),
  KEY `UserGroup_MemberCount_Index` (`MemberCount`),
  KEY `UserGroup_IsDisabled_Index` (`IsDisabled`),
  FULLTEXT KEY `UserGroup_Description_FT` (`Description`),
  FULLTEXT KEY `UserGroup_Name_FT` (`Name`),
  CONSTRAINT `UserGroup_OwnerID_FK` FOREIGN KEY (`OwnerID`) REFERENCES `User` (`ID`) ON DELETE NO ACTION ON UPDATE NO ACTION
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- Dumping data for table test.UserGroup: ~0 rows (approximately)
/*!40000 ALTER TABLE `UserGroup` DISABLE KEYS */;
/*!40000 ALTER TABLE `UserGroup` ENABLE KEYS */;

-- Dumping structure for table test.UserGroupAbandonRequest
CREATE TABLE IF NOT EXISTS `UserGroupAbandonRequest` (
  `ID` int(11) NOT NULL AUTO_INCREMENT,
  `GroupID` int(11) DEFAULT NULL,
  `Code` varchar(128) DEFAULT NULL,
  `TimeExpire` int(11) DEFAULT NULL,
  PRIMARY KEY (`ID`),
  UNIQUE KEY `UserGroupAbandonRequest_Unique` (`GroupID`),
  KEY `UserGroupAbandonRequest_GroupID_FK_idx` (`GroupID`),
  KEY `UserGroupAbandonRequest_Code` (`Code`),
  KEY `UserGroupAbandonRequest_TimeExpire` (`TimeExpire`),
  CONSTRAINT `UserGroupAbandonRequest_GroupID_FK` FOREIGN KEY (`GroupID`) REFERENCES `UserGroup` (`ID`) ON DELETE NO ACTION ON UPDATE NO ACTION
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- Dumping data for table test.UserGroupAbandonRequest: ~0 rows (approximately)
/*!40000 ALTER TABLE `UserGroupAbandonRequest` DISABLE KEYS */;
/*!40000 ALTER TABLE `UserGroupAbandonRequest` ENABLE KEYS */;

-- Dumping structure for table test.UserGroupChangeOwnershipRequest
CREATE TABLE IF NOT EXISTS `UserGroupChangeOwnershipRequest` (
  `ID` int(11) NOT NULL AUTO_INCREMENT,
  `GroupID` int(11) DEFAULT NULL,
  `UserID` int(11) DEFAULT NULL,
  `NewOwnerType` int(11) DEFAULT '0',
  `NewGroupID` int(11) DEFAULT '0',
  `Code` varchar(128) DEFAULT NULL,
  `TimeExpire` int(11) DEFAULT NULL,
  PRIMARY KEY (`ID`),
  UNIQUE KEY `UserGroupChangeOwnershipRequest_Unique` (`GroupID`),
  KEY `UserGroupChangeOwnershipRequest_GroupID_FK_idx` (`GroupID`),
  KEY `UserGroupChangeOwnershipRequest_Code` (`Code`),
  KEY `UserGroupChangeOwnershipRequest_TimeExpire` (`TimeExpire`),
  CONSTRAINT `UserGroupChangeOwnershipRequest_GroupID_FK` FOREIGN KEY (`GroupID`) REFERENCES `UserGroup` (`ID`) ON DELETE NO ACTION ON UPDATE NO ACTION
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- Dumping data for table test.UserGroupChangeOwnershipRequest: ~0 rows (approximately)
/*!40000 ALTER TABLE `UserGroupChangeOwnershipRequest` DISABLE KEYS */;
/*!40000 ALTER TABLE `UserGroupChangeOwnershipRequest` ENABLE KEYS */;

-- Dumping structure for table test.UserGroupDailyEarning
CREATE TABLE IF NOT EXISTS `UserGroupDailyEarning` (
  `ID` int(11) NOT NULL AUTO_INCREMENT,
  `GroupID` int(11) DEFAULT NULL,
  `Coins` int(11) DEFAULT NULL,
  `TimeStart` int(11) DEFAULT NULL,
  `TimeEnd` int(11) DEFAULT NULL,
  `TransactionsCount` int(11) DEFAULT '0',
  `Status` int(11) DEFAULT '0',
  PRIMARY KEY (`ID`),
  KEY `UserDailyEarning_GroupID_FK_idx` (`GroupID`),
  KEY `UserDailyEarning_TimeStart_Index` (`TimeStart`),
  KEY `UserDailyEarning_TimeEnd_Index` (`TimeEnd`),
  KEY `UserDailyEarning_Status_Index` (`Status`),
  CONSTRAINT `UserDailyEarning_GroupID_FK` FOREIGN KEY (`GroupID`) REFERENCES `UserGroup` (`ID`) ON DELETE NO ACTION ON UPDATE NO ACTION
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- Dumping data for table test.UserGroupDailyEarning: ~0 rows (approximately)
/*!40000 ALTER TABLE `UserGroupDailyEarning` DISABLE KEYS */;
/*!40000 ALTER TABLE `UserGroupDailyEarning` ENABLE KEYS */;

-- Dumping structure for table test.UserGroupJoinRequest
CREATE TABLE IF NOT EXISTS `UserGroupJoinRequest` (
  `ID` int(11) NOT NULL AUTO_INCREMENT,
  `GroupID` int(11) DEFAULT NULL,
  `UserID` int(11) DEFAULT NULL,
  `TimeRequest` int(11) DEFAULT NULL,
  PRIMARY KEY (`ID`),
  UNIQUE KEY `UserGroupJoinRequest_Unique` (`GroupID`,`UserID`),
  KEY `UserGroupJoinRequest_GroupID_idx` (`GroupID`),
  KEY `UserGroupJoinRequest_UserID_FK_idx` (`UserID`),
  KEY `UserGroupJoinRequest_TimeRequest_Index` (`TimeRequest`),
  CONSTRAINT `UserGroupJoinRequest_GroupID` FOREIGN KEY (`GroupID`) REFERENCES `UserGroup` (`ID`) ON DELETE NO ACTION ON UPDATE NO ACTION,
  CONSTRAINT `UserGroupJoinRequest_UserID_FK` FOREIGN KEY (`UserID`) REFERENCES `User` (`ID`) ON DELETE NO ACTION ON UPDATE NO ACTION
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- Dumping data for table test.UserGroupJoinRequest: ~0 rows (approximately)
/*!40000 ALTER TABLE `UserGroupJoinRequest` DISABLE KEYS */;
/*!40000 ALTER TABLE `UserGroupJoinRequest` ENABLE KEYS */;

-- Dumping structure for table test.UserGroupMember
CREATE TABLE IF NOT EXISTS `UserGroupMember` (
  `ID` int(11) NOT NULL AUTO_INCREMENT,
  `GroupID` int(11) NOT NULL,
  `UserID` int(11) DEFAULT NULL,
  `Rank` tinyint(4) DEFAULT '1',
  `IsFavorite` tinyint(4) DEFAULT '0',
  PRIMARY KEY (`ID`),
  UNIQUE KEY `UserGroupMember_Unique` (`GroupID`,`UserID`),
  KEY `UserGroupMember_GroupID_FK_idx` (`GroupID`),
  KEY `UserGroupMember_UserID_FK_idx` (`UserID`),
  KEY `UserGroupMember_Rank_Index` (`Rank`),
  KEY `UserGroupMember_IsFavorite_Index` (`IsFavorite`),
  CONSTRAINT `UserGroupMember_GroupID_FK` FOREIGN KEY (`GroupID`) REFERENCES `UserGroup` (`ID`) ON DELETE NO ACTION ON UPDATE NO ACTION,
  CONSTRAINT `UserGroupMember_UserID_FK` FOREIGN KEY (`UserID`) REFERENCES `User` (`ID`) ON DELETE NO ACTION ON UPDATE NO ACTION
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- Dumping data for table test.UserGroupMember: ~0 rows (approximately)
/*!40000 ALTER TABLE `UserGroupMember` DISABLE KEYS */;
/*!40000 ALTER TABLE `UserGroupMember` ENABLE KEYS */;

-- Dumping structure for table test.UserGroupOutboundRequest
CREATE TABLE IF NOT EXISTS `UserGroupOutboundRequest` (
  `ID` int(11) NOT NULL AUTO_INCREMENT,
  `GroupID` int(11) DEFAULT NULL,
  `UserID` int(11) DEFAULT NULL,
  `TimeRequest` int(11) DEFAULT NULL,
  PRIMARY KEY (`ID`),
  UNIQUE KEY `UserGroupOutboundRequest_Unique` (`GroupID`,`UserID`),
  KEY `UserGroupOutboundRequest_GroupID_FK_idx` (`GroupID`),
  KEY `UserGroupOutboundRequest_UserID_FK_idx` (`UserID`),
  KEY `UserGroupOutboundRequest_TimeRequest_Index` (`TimeRequest`),
  CONSTRAINT `UserGroupOutboundRequest_GroupID_FK` FOREIGN KEY (`GroupID`) REFERENCES `UserGroup` (`ID`) ON DELETE NO ACTION ON UPDATE NO ACTION,
  CONSTRAINT `UserGroupOutboundRequest_UserID_FK` FOREIGN KEY (`UserID`) REFERENCES `User` (`ID`) ON DELETE NO ACTION ON UPDATE NO ACTION
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- Dumping data for table test.UserGroupOutboundRequest: ~0 rows (approximately)
/*!40000 ALTER TABLE `UserGroupOutboundRequest` DISABLE KEYS */;
/*!40000 ALTER TABLE `UserGroupOutboundRequest` ENABLE KEYS */;

-- Dumping structure for table test.UserGroupRank
CREATE TABLE IF NOT EXISTS `UserGroupRank` (
  `GroupID` int(11) NOT NULL,
  `Name` varchar(45) DEFAULT NULL,
  `Rank` tinyint(4) DEFAULT NULL,
  `MemberCount` int(11) DEFAULT '0',
  `PermissionViewWall` tinyint(4) DEFAULT '0',
  `PermissionPostWall` tinyint(4) DEFAULT '0',
  `PermissionModerateWall` tinyint(4) DEFAULT '0',
  `PermissionChangeRank` tinyint(4) DEFAULT '0',
  `PermissionKickUser` tinyint(4) DEFAULT '0',
  `PermissionInviteUser` tinyint(4) DEFAULT '0',
  `PermissionAcceptRequests` tinyint(4) DEFAULT '0',
  `PermissionAnnouncements` tinyint(4) DEFAULT '0',
  `PermissionEvents` tinyint(4) DEFAULT '0',
  `PermissionGroupFunds` tinyint(4) DEFAULT '0',
  `PermissionGroupStore` tinyint(4) DEFAULT '0',
  KEY `UserGroupRank_GroupID_FK_idx` (`GroupID`),
  KEY `UserGroupRank_Rank_Index` (`Rank`),
  CONSTRAINT `UserGroupRank_GroupID_FK` FOREIGN KEY (`GroupID`) REFERENCES `UserGroup` (`ID`) ON DELETE NO ACTION ON UPDATE NO ACTION
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- Dumping data for table test.UserGroupRank: ~0 rows (approximately)
/*!40000 ALTER TABLE `UserGroupRank` DISABLE KEYS */;
/*!40000 ALTER TABLE `UserGroupRank` ENABLE KEYS */;

-- Dumping structure for table test.UserGroupWall
CREATE TABLE IF NOT EXISTS `UserGroupWall` (
  `ID` int(11) NOT NULL AUTO_INCREMENT,
  `GroupID` int(11) NOT NULL,
  `UserID` int(11) DEFAULT NULL,
  `Message` varchar(512) DEFAULT NULL,
  `TimePosted` int(11) DEFAULT NULL,
  `IsPinned` tinyint(4) DEFAULT '0',
  PRIMARY KEY (`ID`),
  KEY `UserGroupWall_GroupID_FK_idx` (`GroupID`),
  KEY `UserGroupWall_UserID_FK_idx` (`UserID`),
  KEY `UserGroupWall_IsPinned_Index` (`IsPinned`),
  KEY `UserGroupWall_TimePosted_Index` (`TimePosted`),
  FULLTEXT KEY `UserGroupWall_Message_FT` (`Message`),
  CONSTRAINT `UserGroupWall_GroupID_FK` FOREIGN KEY (`GroupID`) REFERENCES `UserGroup` (`ID`) ON DELETE NO ACTION ON UPDATE NO ACTION,
  CONSTRAINT `UserGroupWall_UserID_FK` FOREIGN KEY (`UserID`) REFERENCES `User` (`ID`) ON DELETE NO ACTION ON UPDATE NO ACTION
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- Dumping data for table test.UserGroupWall: ~0 rows (approximately)
/*!40000 ALTER TABLE `UserGroupWall` DISABLE KEYS */;
/*!40000 ALTER TABLE `UserGroupWall` ENABLE KEYS */;

-- Dumping structure for table test.UserInventory
CREATE TABLE IF NOT EXISTS `UserInventory` (
  `ID` int(11) NOT NULL AUTO_INCREMENT,
  `UserID` int(11) DEFAULT NULL,
  `ItemID` int(11) DEFAULT NULL,
  `TimeCreated` int(11) DEFAULT NULL,
  `CollectionNumber` int(11) DEFAULT '0',
  `CanTrade` tinyint(4) DEFAULT '1',
  `CrateOpened` int(11) DEFAULT '0',
  `CrateItemID` int(11) DEFAULT '0',
  PRIMARY KEY (`ID`),
  KEY `UserInventory_UserID_FK_idx` (`UserID`),
  KEY `UserInventory_ItemID_FK_idx` (`ItemID`),
  CONSTRAINT `UserInventory_ItemID_FK` FOREIGN KEY (`ItemID`) REFERENCES `Item` (`ID`) ON DELETE NO ACTION ON UPDATE NO ACTION,
  CONSTRAINT `UserInventory_UserID_FK` FOREIGN KEY (`UserID`) REFERENCES `User` (`ID`) ON DELETE NO ACTION ON UPDATE NO ACTION
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- Dumping data for table test.UserInventory: ~0 rows (approximately)
/*!40000 ALTER TABLE `UserInventory` DISABLE KEYS */;
/*!40000 ALTER TABLE `UserInventory` ENABLE KEYS */;

-- Dumping structure for table test.UserIP
CREATE TABLE IF NOT EXISTS `UserIP` (
  `ID` int(11) NOT NULL AUTO_INCREMENT,
  `UserID` int(11) DEFAULT NULL,
  `IP` varchar(60) DEFAULT NULL,
  `TimeFirstUse` int(11) DEFAULT NULL,
  `TimeLastUse` int(11) DEFAULT NULL,
  `City` varchar(128) DEFAULT NULL,
  `Region` varchar(128) DEFAULT NULL,
  `Country` varchar(128) DEFAULT NULL,
  `PostalCode` varchar(10) DEFAULT NULL,
  PRIMARY KEY (`ID`),
  KEY `UserIP_UserID_FK_idx` (`UserID`),
  KEY `UserIP_IP_Index` (`IP`),
  CONSTRAINT `UserIP_UserID_FK` FOREIGN KEY (`UserID`) REFERENCES `User` (`ID`) ON DELETE NO ACTION ON UPDATE NO ACTION
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- Dumping data for table test.UserIP: ~0 rows (approximately)
/*!40000 ALTER TABLE `UserIP` DISABLE KEYS */;
/*!40000 ALTER TABLE `UserIP` ENABLE KEYS */;

-- Dumping structure for table test.UserIPBan
CREATE TABLE IF NOT EXISTS `UserIPBan` (
  `ID` int(11) NOT NULL AUTO_INCREMENT,
  `IPAddress` varchar(60) DEFAULT NULL,
  `TimePlaced` int(11) DEFAULT NULL,
  `TimeExpires` int(11) DEFAULT NULL,
  `AdminID` int(11) DEFAULT NULL,
  `AdminReason` varchar(256) DEFAULT NULL,
  PRIMARY KEY (`ID`),
  KEY `UserIPBan_TimePlaced_Index` (`TimePlaced`),
  KEY `UserIPBan_TimeExpires` (`TimeExpires`),
  KEY `UserIPBan_AdminID_FK_idx` (`AdminID`),
  CONSTRAINT `UserIPBan_AdminID_FK` FOREIGN KEY (`AdminID`) REFERENCES `User` (`ID`) ON DELETE NO ACTION ON UPDATE NO ACTION
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- Dumping data for table test.UserIPBan: ~0 rows (approximately)
/*!40000 ALTER TABLE `UserIPBan` DISABLE KEYS */;
/*!40000 ALTER TABLE `UserIPBan` ENABLE KEYS */;

-- Dumping structure for table test.UserLoginLog
CREATE TABLE IF NOT EXISTS `UserLoginLog` (
  `ID` int(11) NOT NULL AUTO_INCREMENT,
  `UserID` int(11) DEFAULT NULL,
  `IP` varchar(60) DEFAULT NULL,
  `TimeLog` int(11) DEFAULT NULL,
  PRIMARY KEY (`ID`),
  KEY `UserLoginLog_TimeLog_Index` (`TimeLog`),
  KEY `UserLoginLog_IP_Index` (`IP`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- Dumping data for table test.UserLoginLog: ~0 rows (approximately)
/*!40000 ALTER TABLE `UserLoginLog` DISABLE KEYS */;
/*!40000 ALTER TABLE `UserLoginLog` ENABLE KEYS */;

-- Dumping structure for table test.UserLogs
CREATE TABLE IF NOT EXISTS `UserLogs` (
  `ID` int(11) NOT NULL AUTO_INCREMENT,
  `UserID` int(11) DEFAULT NULL,
  `Message` longtext,
  `LogTime` int(11) DEFAULT NULL,
  `IP` varchar(100) DEFAULT NULL,
  PRIMARY KEY (`ID`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- Dumping data for table test.UserLogs: ~0 rows (approximately)
/*!40000 ALTER TABLE `UserLogs` DISABLE KEYS */;
/*!40000 ALTER TABLE `UserLogs` ENABLE KEYS */;

-- Dumping structure for table test.UserMessage
CREATE TABLE IF NOT EXISTS `UserMessage` (
  `ID` int(11) NOT NULL AUTO_INCREMENT,
  `SenderID` int(11) DEFAULT NULL,
  `ReceiverID` int(11) DEFAULT NULL,
  `Title` varchar(50) DEFAULT NULL,
  `Message` varchar(1000) DEFAULT NULL,
  `TimeSent` int(11) DEFAULT '0',
  `TimeRead` int(11) DEFAULT '0',
  `IsRead` int(11) DEFAULT '0',
  `Archived` int(11) DEFAULT '0',
  PRIMARY KEY (`ID`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- Dumping data for table test.UserMessage: ~0 rows (approximately)
/*!40000 ALTER TABLE `UserMessage` DISABLE KEYS */;
/*!40000 ALTER TABLE `UserMessage` ENABLE KEYS */;

-- Dumping structure for table test.UsernameHistory
CREATE TABLE IF NOT EXISTS `UsernameHistory` (
  `ID` int(11) NOT NULL AUTO_INCREMENT,
  `UserID` int(11) DEFAULT NULL,
  `Username` varchar(20) DEFAULT NULL,
  `Time` int(11) DEFAULT NULL,
  PRIMARY KEY (`ID`),
  KEY `UsernameHistory_UserID_FK_idx` (`UserID`),
  KEY `UsernameHistory_Username_Index` (`Username`),
  FULLTEXT KEY `UsernameHistory_Username_FT` (`Username`),
  CONSTRAINT `UsernameHistory_UserID_FK` FOREIGN KEY (`UserID`) REFERENCES `User` (`ID`) ON DELETE NO ACTION ON UPDATE NO ACTION
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- Dumping data for table test.UsernameHistory: ~0 rows (approximately)
/*!40000 ALTER TABLE `UsernameHistory` DISABLE KEYS */;
/*!40000 ALTER TABLE `UsernameHistory` ENABLE KEYS */;

-- Dumping structure for table test.UserNotification
CREATE TABLE IF NOT EXISTS `UserNotification` (
  `ID` int(11) NOT NULL AUTO_INCREMENT,
  `SenderID` int(11) DEFAULT NULL,
  `ReceiverID` int(11) DEFAULT NULL,
  `TimeNotification` int(11) DEFAULT '0',
  `TimeRead` int(11) DEFAULT '0',
  `NotificationType` int(11) DEFAULT '0',
  `RelevanceID` int(11) DEFAULT '0',
  `Message` varchar(512) DEFAULT NULL,
  `URL` varchar(256) DEFAULT NULL,
  PRIMARY KEY (`ID`),
  KEY `UserNotification_ReceiverID_FK_idx` (`ReceiverID`),
  KEY `UserNotification_SenderID_FK_idx` (`SenderID`),
  KEY `UserNotification_TimeNotification_Index` (`TimeNotification`),
  KEY `UserNotification_TimeRead_Index` (`TimeRead`),
  KEY `UserNotification_NotificationType` (`NotificationType`),
  KEY `UserNotification_RelevanceID` (`RelevanceID`),
  KEY `UserNotification_NotificationTypeReceiverID_Index` (`ReceiverID`,`NotificationType`),
  CONSTRAINT `UserNotification_ReceiverID_FK` FOREIGN KEY (`ReceiverID`) REFERENCES `User` (`ID`) ON DELETE NO ACTION ON UPDATE NO ACTION,
  CONSTRAINT `UserNotification_SenderID_FK` FOREIGN KEY (`SenderID`) REFERENCES `User` (`ID`) ON DELETE NO ACTION ON UPDATE NO ACTION
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- Dumping data for table test.UserNotification: ~0 rows (approximately)
/*!40000 ALTER TABLE `UserNotification` DISABLE KEYS */;
/*!40000 ALTER TABLE `UserNotification` ENABLE KEYS */;

-- Dumping structure for table test.UserNotificationMessage
CREATE TABLE IF NOT EXISTS `UserNotificationMessage` (
  `ID` int(11) NOT NULL AUTO_INCREMENT,
  `UserID` int(11) DEFAULT NULL,
  `Title` varchar(512) DEFAULT NULL,
  `Message` text,
  `TimeMessage` int(11) DEFAULT '0',
  PRIMARY KEY (`ID`),
  KEY `UserNotificationMessage_UserID_FK_idx` (`UserID`),
  KEY `UserNotificationMessage_TimeMessage_Index` (`TimeMessage`),
  CONSTRAINT `UserNotificationMessage_UserID_FK` FOREIGN KEY (`UserID`) REFERENCES `User` (`ID`) ON DELETE NO ACTION ON UPDATE NO ACTION
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- Dumping data for table test.UserNotificationMessage: ~0 rows (approximately)
/*!40000 ALTER TABLE `UserNotificationMessage` DISABLE KEYS */;
/*!40000 ALTER TABLE `UserNotificationMessage` ENABLE KEYS */;

-- Dumping structure for table test.UserPassResetRequest
CREATE TABLE IF NOT EXISTS `UserPassResetRequest` (
  `ID` int(11) NOT NULL AUTO_INCREMENT,
  `UserID` int(11) DEFAULT NULL,
  `IP` varchar(60) DEFAULT NULL,
  `Code` varchar(256) DEFAULT NULL,
  `TimeRequest` int(11) DEFAULT NULL,
  `TimeExpires` int(11) DEFAULT NULL,
  `Redeemed` int(11) DEFAULT '0',
  PRIMARY KEY (`ID`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- Dumping data for table test.UserPassResetRequest: ~0 rows (approximately)
/*!40000 ALTER TABLE `UserPassResetRequest` DISABLE KEYS */;
/*!40000 ALTER TABLE `UserPassResetRequest` ENABLE KEYS */;

-- Dumping structure for table test.UserPasswordChange
CREATE TABLE IF NOT EXISTS `UserPasswordChange` (
  `ID` int(11) NOT NULL AUTO_INCREMENT,
  `UserID` int(11) NOT NULL,
  `PreviousPassword` longtext NOT NULL,
  `NewPassword` longtext NOT NULL,
  `RevertCode` longtext NOT NULL,
  `Expire` longtext NOT NULL,
  `IP` longtext NOT NULL,
  `Reverted` int(11) DEFAULT '0',
  PRIMARY KEY (`ID`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- Dumping data for table test.UserPasswordChange: ~0 rows (approximately)
/*!40000 ALTER TABLE `UserPasswordChange` DISABLE KEYS */;
/*!40000 ALTER TABLE `UserPasswordChange` ENABLE KEYS */;

-- Dumping structure for table test.UserPaymentHistory
CREATE TABLE IF NOT EXISTS `UserPaymentHistory` (
  `ID` int(11) NOT NULL AUTO_INCREMENT,
  `UserID` int(11) DEFAULT NULL,
  `PlanID` tinyint(4) DEFAULT NULL COMMENT '0-2=VIP',
  `PaymentType` tinyint(4) DEFAULT NULL COMMENT '0 - Credit Card\n1 - PayPal\n2 - Credits',
  `TimePayment` int(11) DEFAULT NULL,
  `PayerName` varchar(100) DEFAULT NULL,
  `PayerEmail` varchar(100) DEFAULT NULL,
  `PayerAddress` varchar(256) DEFAULT NULL,
  `PayerCity` varchar(100) DEFAULT NULL,
  `PayerState` varchar(100) DEFAULT NULL,
  `PayerCountry` varchar(100) DEFAULT NULL,
  `TransactionID` varchar(128) DEFAULT NULL,
  `SubscriptionID` varchar(128) DEFAULT NULL,
  `LastFour` int(11) DEFAULT NULL,
  `RedeemedRefund` tinyint(4) DEFAULT '0' COMMENT 'Expires 10/05/2017',
  `Status` tinyint(4) DEFAULT '0',
  PRIMARY KEY (`ID`),
  KEY `UserPaymentHistory_UserID_FK_idx` (`UserID`),
  KEY `UserPaymentHistory_TimePayment_Index` (`TimePayment`),
  CONSTRAINT `UserPaymentHistory_UserID_FK` FOREIGN KEY (`UserID`) REFERENCES `User` (`ID`) ON DELETE NO ACTION ON UPDATE NO ACTION
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- Dumping data for table test.UserPaymentHistory: ~0 rows (approximately)
/*!40000 ALTER TABLE `UserPaymentHistory` DISABLE KEYS */;
/*!40000 ALTER TABLE `UserPaymentHistory` ENABLE KEYS */;

-- Dumping structure for table test.UserProfileView
CREATE TABLE IF NOT EXISTS `UserProfileView` (
  `UserID` int(11) DEFAULT NULL,
  `TargetID` int(11) DEFAULT NULL,
  `Recurring` int(11) DEFAULT NULL,
  KEY `UserProfileView_UserID_FK_idx` (`UserID`),
  KEY `UserProfileView_TargetID_FK_idx` (`TargetID`),
  CONSTRAINT `UserProfileView_TargetID_FK` FOREIGN KEY (`TargetID`) REFERENCES `User` (`ID`) ON DELETE NO ACTION ON UPDATE NO ACTION,
  CONSTRAINT `UserProfileView_UserID_FK` FOREIGN KEY (`UserID`) REFERENCES `User` (`ID`) ON DELETE NO ACTION ON UPDATE NO ACTION
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- Dumping data for table test.UserProfileView: ~0 rows (approximately)
/*!40000 ALTER TABLE `UserProfileView` DISABLE KEYS */;
/*!40000 ALTER TABLE `UserProfileView` ENABLE KEYS */;

-- Dumping structure for table test.UserSearchHistory
CREATE TABLE IF NOT EXISTS `UserSearchHistory` (
  `UserID` int(11) NOT NULL,
  `ContentType` int(11) DEFAULT NULL,
  `ContentID` int(11) DEFAULT NULL,
  `TimeSearch` int(11) DEFAULT NULL,
  UNIQUE KEY `UserSearchHistory_Uniques` (`UserID`,`ContentType`,`ContentID`),
  KEY `UserSearchHistory_TimeSearch_Index` (`TimeSearch`),
  KEY `UserSearchHistory_UserID_FK_idx` (`UserID`),
  CONSTRAINT `UserSearchHistory_UserID_FK` FOREIGN KEY (`UserID`) REFERENCES `User` (`ID`) ON DELETE NO ACTION ON UPDATE NO ACTION
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- Dumping data for table test.UserSearchHistory: ~0 rows (approximately)
/*!40000 ALTER TABLE `UserSearchHistory` DISABLE KEYS */;
/*!40000 ALTER TABLE `UserSearchHistory` ENABLE KEYS */;

-- Dumping structure for table test.UserTrade
CREATE TABLE IF NOT EXISTS `UserTrade` (
  `ID` int(11) NOT NULL AUTO_INCREMENT,
  `RequesterID` int(11) DEFAULT NULL,
  `ReceiverID` int(11) DEFAULT NULL,
  `Status` int(11) DEFAULT '0',
  `Time` int(11) DEFAULT NULL,
  `Expires` int(11) DEFAULT NULL,
  `GivingOne` int(11) DEFAULT '0',
  `GivingTwo` int(11) DEFAULT '0',
  `GivingThree` int(11) DEFAULT '0',
  `GivingFour` int(11) DEFAULT '0',
  `GivingCredits` int(11) DEFAULT '0',
  `WantOne` int(11) DEFAULT '0',
  `WantTwo` int(11) DEFAULT '0',
  `WantThree` int(11) DEFAULT '0',
  `WantFour` int(11) DEFAULT '0',
  `WantCredits` int(11) DEFAULT '0',
  `UpdatedOn` int(11) DEFAULT NULL,
  PRIMARY KEY (`ID`),
  KEY `UserTrade_RequesterID_FK_idx` (`RequesterID`),
  KEY `UserTrade_ReceiverID_FK_idx` (`ReceiverID`),
  KEY `UserTrade_Expires_Index` (`Expires`),
  CONSTRAINT `UserTrade_ReceiverID_FK` FOREIGN KEY (`ReceiverID`) REFERENCES `User` (`ID`) ON DELETE NO ACTION ON UPDATE NO ACTION,
  CONSTRAINT `UserTrade_RequesterID_FK` FOREIGN KEY (`RequesterID`) REFERENCES `User` (`ID`) ON DELETE NO ACTION ON UPDATE NO ACTION
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- Dumping data for table test.UserTrade: ~0 rows (approximately)
/*!40000 ALTER TABLE `UserTrade` DISABLE KEYS */;
/*!40000 ALTER TABLE `UserTrade` ENABLE KEYS */;

-- Dumping structure for table test.UserTransactionLog
CREATE TABLE IF NOT EXISTS `UserTransactionLog` (
  `ID` int(11) NOT NULL AUTO_INCREMENT,
  `UserID` int(11) DEFAULT NULL,
  `EventID` int(11) DEFAULT NULL,
  `ReferenceID` int(11) DEFAULT NULL,
  `PreviousBalance` int(11) DEFAULT NULL,
  `NewBalance` int(11) DEFAULT NULL,
  `TimeTransaction` varchar(45) DEFAULT NULL,
  PRIMARY KEY (`ID`),
  KEY `UserTransactionLog_UserID_FK_idx` (`UserID`),
  KEY `UserTransactionLog_TimeTransaction_Index` (`TimeTransaction`),
  KEY `UserTransactionLog_EventID_Index` (`EventID`),
  KEY `UserTransactionLog_ReferenceID_Index` (`ReferenceID`),
  CONSTRAINT `UserTransactionLog_UserID_FK` FOREIGN KEY (`UserID`) REFERENCES `User` (`ID`) ON DELETE NO ACTION ON UPDATE NO ACTION
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- Dumping data for table test.UserTransactionLog: ~0 rows (approximately)
/*!40000 ALTER TABLE `UserTransactionLog` DISABLE KEYS */;
/*!40000 ALTER TABLE `UserTransactionLog` ENABLE KEYS */;

-- Dumping structure for table test.UserVerifyEmail
CREATE TABLE IF NOT EXISTS `UserVerifyEmail` (
  `ID` int(11) NOT NULL AUTO_INCREMENT,
  `UserID` int(11) DEFAULT NULL,
  `TimeSent` int(11) DEFAULT NULL,
  `VerifyType` int(11) DEFAULT NULL,
  `VerifyCode` varchar(128) DEFAULT NULL,
  PRIMARY KEY (`ID`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- Dumping data for table test.UserVerifyEmail: ~0 rows (approximately)
/*!40000 ALTER TABLE `UserVerifyEmail` DISABLE KEYS */;
/*!40000 ALTER TABLE `UserVerifyEmail` ENABLE KEYS */;

-- Dumping structure for table test.UserWall
CREATE TABLE IF NOT EXISTS `UserWall` (
  `ID` int(11) NOT NULL AUTO_INCREMENT,
  `UserID` int(11) DEFAULT NULL,
  `PosterID` int(11) DEFAULT NULL,
  `Post` varchar(256) DEFAULT NULL,
  `TimePosted` int(11) DEFAULT NULL,
  PRIMARY KEY (`ID`),
  KEY `UserWall_UserID_FK_idx` (`UserID`),
  KEY `UserWall_PosterID_FK_idx` (`PosterID`),
  KEY `UserWall_TimePosted_Index` (`TimePosted`),
  CONSTRAINT `UserWall_PosterID_FK` FOREIGN KEY (`PosterID`) REFERENCES `User` (`ID`) ON DELETE NO ACTION ON UPDATE NO ACTION,
  CONSTRAINT `UserWall_UserID_FK` FOREIGN KEY (`UserID`) REFERENCES `User` (`ID`) ON DELETE NO ACTION ON UPDATE NO ACTION
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- Dumping data for table test.UserWall: ~0 rows (approximately)
/*!40000 ALTER TABLE `UserWall` DISABLE KEYS */;
/*!40000 ALTER TABLE `UserWall` ENABLE KEYS */;

/*!40101 SET SQL_MODE=IFNULL(@OLD_SQL_MODE, '') */;
/*!40014 SET FOREIGN_KEY_CHECKS=IF(@OLD_FOREIGN_KEY_CHECKS IS NULL, 1, @OLD_FOREIGN_KEY_CHECKS) */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
