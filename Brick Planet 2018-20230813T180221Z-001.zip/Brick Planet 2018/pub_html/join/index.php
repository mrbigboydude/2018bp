<?php
require_once($_SERVER['DOCUMENT_ROOT']."/../private/config.php");
header("Location: ".$serverName."/register/");
die;
?>