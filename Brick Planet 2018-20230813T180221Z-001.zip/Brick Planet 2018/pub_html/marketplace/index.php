<?php
require_once($_SERVER['DOCUMENT_ROOT']."/../private/header.php");

	echo '
	<script>
		document.title = "Marketplace - BLOX City";
	</script>
	<div class="lg-container center games-construction">
		<i class="material-icons">timelapse</i>
		<div>The marketplace feature is coming soon.<br />Check back soon!</div>
	</div>
	';

require_once($_SERVER['DOCUMENT_ROOT']."/../private/footer.php");