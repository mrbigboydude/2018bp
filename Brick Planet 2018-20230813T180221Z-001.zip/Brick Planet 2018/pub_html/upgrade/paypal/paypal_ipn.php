<?php
require_once($_SERVER['DOCUMENT_ROOT']."/../private/db.php");
require_once($_SERVER['DOCUMENT_ROOT']."/../private/memcached.php");
require_once($_SERVER['DOCUMENT_ROOT']."/../private/paypal.php");

	// STEP 1: Read POST data

	// reading posted data from directly from $_POST causes serialization 
	// issues with array data in POST
	// reading raw POST data from input stream instead. 
	$raw_post_data = file_get_contents('php://input');
	$raw_post_array = explode('&', $raw_post_data);
	$myPost = array();
	foreach ($raw_post_array as $keyval) {
	  $keyval = explode ('=', $keyval);
	  if (count($keyval) == 2)
		 $myPost[$keyval[0]] = urldecode($keyval[1]);
	}
	// read the post from PayPal system and add 'cmd'
	$req = 'cmd=_notify-validate';
	if(function_exists('get_magic_quotes_gpc')) {
	   $get_magic_quotes_exists = true;
	} 
	foreach ($myPost as $key => $value) {        
	   if($get_magic_quotes_exists == true && get_magic_quotes_gpc() == 1) { 
			$value = urlencode(stripslashes($value)); 
	   } else {
			$value = urlencode($value);
	   }
	   $req .= "&$key=$value";
	}

	// STEP 2: Post IPN data back to paypal to validate

	$ch = curl_init('https://www.paypal.com/cgi-bin/webscr'); // change to [...]sandbox.paypal[...] when using sandbox to test
	curl_setopt($ch, CURLOPT_HTTP_VERSION, CURL_HTTP_VERSION_1_1);
	curl_setopt($ch, CURLOPT_POST, 1);
	curl_setopt($ch, CURLOPT_RETURNTRANSFER,1);
	curl_setopt($ch, CURLOPT_POSTFIELDS, $req);
	curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, 1);
	curl_setopt($ch, CURLOPT_SSL_VERIFYHOST, 2);
	curl_setopt($ch, CURLOPT_FORBID_REUSE, 1);
	curl_setopt($ch, CURLOPT_HTTPHEADER, array('Connection: Close'));

	// In wamp like environments that do not come bundled with root authority certificates,
	// please download 'cacert.pem' from "http://curl.haxx.se/docs/caextract.html" and set the directory path 
	// of the certificate as shown below.
	// curl_setopt($ch, CURLOPT_CAINFO, dirname(__FILE__) . '/cacert.pem');
	if( !($res = curl_exec($ch)) ) {
		// error_log("Got " . curl_error($ch) . " when processing IPN data");
		curl_close($ch);
		exit;
	}
	curl_close($ch);
	
	if (strcmp ($res, "VERIFIED") == 0) {
		
		$item_name = !empty($_POST['item_name']) ? $_POST['item_name'] : $_POST['item_name1'];
		$payment_status = $_POST['payment_status'];
		$payment_amount = !empty($_POST['mc_gross']) ? $_POST['mc_gross'] : $_POST['mc_gross1'];
		$payment_currency = $_POST['mc_currency'];
		$txn_id = $_POST['txn_id'];
		$txn_type = $_POST['txn_type'];
		$receiver_email = $_POST['receiver_email'];
		$payer_email = $_POST['payer_email'];
		$custom = (int)$_POST['custom'];
		
		$getUser = $db->prepare("SELECT User.ID, User.Username, User.Email, User.LastIP, User.VIP, User.VIP_Recurring, User.VIP_Expires, User.StripeKey, User.UpgradesCount, User.DiscordId FROM User WHERE User.ID = ?");
		$getUser->bindValue(1, $custom, PDO::PARAM_INT);
		$getUser->execute();
		
		if ($getUser->rowCount() > 0) {
			
			$gU = $getUser->fetch(PDO::FETCH_OBJ);
			
			if ($_POST['payment_status'] == 'Completed' && $receiver_email == 'corporate@brickplanet.com' && $gU->VIP == 0 && ($item_name == 'Brick Builder (monthly)' || $item_name == 'Planet Constructor (monthly)' || $item_name == 'Master Architect (monthly)')) {
				
				if ($gU->UpgradesCount == 0) {
					
					$Update = $db->prepare("UPDATE User SET CurrencyCoins = CurrencyCoins + 500 WHERE ID = ".$gU->ID."");
					$Update->execute();
					
				}
				
				switch ($item_name) {
					case 'Brick Builder (monthly)':
						$PlanID = 1;
						$PlanCoins = 100;
						$PlanPrice = 4.95;
						break;
					case 'Planet Constructor (monthly)':
						$PlanID = 2;
						$PlanCoins = 200;
						$PlanPrice = 11.95;
						break;
					case 'Master Architect (monthly)':
						$PlanID = 3;
						$PlanCoins = 300;
						$PlanPrice = 18.95;
						break;
				}
				
				$Insert = $db->prepare("INSERT INTO UserPaymentHistory (UserID, PlanID, PaymentType, TimePayment, PayerName, PayerEmail, PayerAddress, PayerCity, PayerState, PayerCountry, TransactionID, SubscriptionID, LastFour) VALUES(".$gU->ID.", ".$PlanID.", 1, ".time().", ?, '".$gU->Email."', ?, ?, ?, ?, ?, ?, ?)");
				$Insert->bindValue(1, $_POST['first_name'].' '.$_POST['last_name'], PDO::PARAM_STR);
				$Insert->bindValue(2, $_POST['address_street'], PDO::PARAM_STR);
				$Insert->bindValue(3, $_POST['address_city'], PDO::PARAM_STR);
				$Insert->bindValue(4, $_POST['address_state'], PDO::PARAM_STR);
				$Insert->bindValue(5, $_POST['address_country_code'], PDO::PARAM_STR);
				$Insert->bindValue(6, $txn_id, PDO::PARAM_STR);
				$Insert->bindValue(7, $_POST['subscr_id'], PDO::PARAM_STR);
				$Insert->bindValue(8, 0000, PDO::PARAM_INT);
				$Insert->execute();
				
				$Update = $db->prepare("UPDATE User SET CurrencyCoins = CurrencyCoins + ".$PlanCoins.", NextUpgradeCoinPay = ".(time() + 86400).", VIP = ".$PlanID.", VIP_Recurring = 1, VIP_Expires = ".(time() + 2678400)." WHERE ID = ".$gU->ID."");
				$Update->execute();
				
				$Insert = $db->prepare("INSERT INTO UserBadge (UserID, AchievementID) VALUES(".$gU->ID.", ".($PlanID+8).")");
				$Insert->execute();
				
				// Discord verification
				if ($gU->DiscordId > 0 && $gU->VIP == 0) {
					$ch = curl_init();
					curl_setopt($ch, CURLOPT_URL, 'http://discordapi.brickplanet.com/modify-user-vip?userId='.$gU->DiscordId.'&action=add-role&level=' . $PlanID);
					curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
					$result = curl_exec($ch);
					curl_close($ch);
				} else if ($gU->DiscordId > 0 && $gU->VIP > 0) {
					$ch = curl_init();
					curl_setopt($ch, CURLOPT_URL, 'http://discordapi.brickplanet.com/modify-user-vip?userId='.$gU->DiscordId.'&action=change-role&level=' . $gU->VIP . '&newlevel=' . $PlanID);
					curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
					$result = curl_exec($ch);
					curl_close($ch);
				}
				
				if ($PlanID == 1) {
					
					$Count = $db->prepare("SELECT COUNT(*) FROM UserInventory WHERE UserID = ".$gU->ID." AND ItemID = 19141");
					$Count->execute();
					$Count = $Count->fetchColumn();
					
					if ($Count == 0) {
						$Insert = $db->prepare("INSERT INTO UserInventory (UserID, ItemID, TimeCreated) VALUES(".$gU->ID.", 19141, ".time().")");
						$Insert->execute();
					}
					
				} else if ($PlanID == 2) {
					
					$Count = $db->prepare("SELECT COUNT(*) FROM UserInventory WHERE UserID = ".$gU->ID." AND ItemID = 18595");
					$Count->execute();
					$Count = $Count->fetchColumn();
					
					if ($Count == 0) {
						$Insert = $db->prepare("INSERT INTO UserInventory (UserID, ItemID, TimeCreated) VALUES(".$gU->ID.", 18595, ".time().")");
						$Insert->execute();
					}
					
					$Count = $db->prepare("SELECT COUNT(*) FROM UserInventory WHERE UserID = ".$gU->ID." AND ItemID = 18611");
					$Count->execute();
					$Count = $Count->fetchColumn();
					
					if ($Count == 0) {
						$Insert = $db->prepare("INSERT INTO UserInventory (UserID, ItemID, TimeCreated) VALUES(".$gU->ID.", 18611, ".time().")");
						$Insert->execute();
					}
					
				} else if ($PlanID == 3) {
					
					$Count = $db->prepare("SELECT COUNT(*) FROM UserInventory WHERE UserID = ".$gU->ID." AND ItemID = 18555");
					$Count->execute();
					$Count = $Count->fetchColumn();
					
					if ($Count == 0) {
						$Insert = $db->prepare("INSERT INTO UserInventory (UserID, ItemID, TimeCreated) VALUES(".$gU->ID.", 18555, ".time().")");
						$Insert->execute();
					}
					
					$Count = $db->prepare("SELECT COUNT(*) FROM UserInventory WHERE UserID = ".$gU->ID." AND ItemID = 18562");
					$Count->execute();
					$Count = $Count->fetchColumn();
					
					if ($Count == 0) {
						$Insert = $db->prepare("INSERT INTO UserInventory (UserID, ItemID, TimeCreated) VALUES(".$gU->ID.", 18562, ".time().")");
						$Insert->execute();
					}
					
					$Count = $db->prepare("SELECT COUNT(*) FROM UserInventory WHERE UserID = ".$gU->ID." AND ItemID = 18586");
					$Count->execute();
					$Count = $Count->fetchColumn();
					
					if ($Count == 0) {
						$Insert = $db->prepare("INSERT INTO UserInventory (UserID, ItemID, TimeCreated) VALUES(".$gU->ID.", 18586, ".time().")");
						$Insert->execute();
					}
					
					$Count = $db->prepare("SELECT COUNT(*) FROM UserInventory WHERE UserID = ".$gU->ID." AND ItemID = 18589");
					$Count->execute();
					$Count = $Count->fetchColumn();
					
					if ($Count == 0) {
						$Insert = $db->prepare("INSERT INTO UserInventory (UserID, ItemID, TimeCreated) VALUES(".$gU->ID.", 18589, ".time().")");
						$Insert->execute();
					}
					
				}
				
			} else if ($_POST['payment_status'] == 'Completed' && $receiver_email == 'corporate@brickplanet.com' && $gU->VIP > 0 && ($item_name == 'Brick Builder (month)' || $item_name == 'Planet Constructor (month)' || $item_name == 'Master Architect (month)')) {
				
				switch ($item_name) {
					case 'Brick Builder (month)':
						$PlanID = 1;
						$PlanCoins = 100;
						$PlanPrice = 4.95;
						break;
					case 'Planet Constructor (month)':
						$PlanID = 2;
						$PlanCoins = 200;
						$PlanPrice = 11.95;
						break;
					case 'Master Architect (month)':
						$PlanID = 3;
						$PlanCoins = 300;
						$PlanPrice = 18.95;
						break;
				}
				
				switch ($gU->VIP) {
					case 1:
						$CurrentPrice = 4.95;
						break;
					case 2:
						$CurrentPrice = 11.95;
						break;
					case 3:
						$CurrentPrice = 18.95;
						break;
				}
				
				if ($payment_amount != $PlanPrice) {
					
					$CalculateDays = round((($gU->VIP_Expires - time())/86400));
					$CalculateDays = $CalculateDays/31;
					$ProRateCredit = number_format(($CurrentPrice*$CalculateDays), 2);
					$PlanPrice = $PlanPrice - $ProRateCredit;
					
					if ($payment_amount != $PlanPrice) {
						
						die;
						
					} else {
						
						if ($gU->VIP_Recurring == 1) {
						
							$query = $db->prepare("SELECT PaymentType, SubscriptionID FROM UserPaymentHistory WHERE UserID = ".$gU->ID." AND PlanID IN(1, 2, 3) ORDER BY TimePayment DESC LIMIT 1");
							$query->execute();
							
							if ($query->rowCount() > 0) {
								
								$q = $query->fetch(PDO::FETCH_OBJ);
								
								if ($q->PaymentType == 0) {
									
									require_once('/var/www/html/root/html/upgrade/vendor/autoload.php');
									
									\Stripe\Stripe::setApiKey('sk_live_fYu99GFyStXZ8vgBpIL5gbOj');
									
									$customer = \Stripe\Customer::retrieve($gU->StripeKey);
									
									if ($customer->subscriptions->total_count > 0) {
										
										$customer->cancelSubscription();
										
									}
									
								} else if ($q->PaymentType == 1) {
									
									CancelPaypalSubscription($q->SubscriptionID, 'Cancel');
									
								}
							
							}
						
						}
						
						if ($gU->UpgradesCount == 0) {
							
							$Update = $db->prepare("UPDATE User SET CurrencyCoins = CurrencyCoins + 500 WHERE ID = ".$gU->ID."");
							$Update->execute();
							
						}
						
						$Insert = $db->prepare("INSERT INTO UserPaymentHistory (UserID, PlanID, PaymentType, TimePayment, PayerName, PayerEmail, PayerAddress, PayerCity, PayerState, PayerCountry, TransactionID, SubscriptionID, LastFour) VALUES(".$gU->ID.", ".$PlanID.", 1, ".time().", ?, '".$gU->Email."', ?, ?, ?, ?, ?, ?, ?)");
						$Insert->bindValue(1, $_POST['first_name'].' '.$_POST['last_name'], PDO::PARAM_STR);
						$Insert->bindValue(2, $_POST['address_street'], PDO::PARAM_STR);
						$Insert->bindValue(3, $_POST['address_city'], PDO::PARAM_STR);
						$Insert->bindValue(4, $_POST['address_state'], PDO::PARAM_STR);
						$Insert->bindValue(5, $_POST['address_country_code'], PDO::PARAM_STR);
						$Insert->bindValue(6, $txn_id, PDO::PARAM_STR);
						$Insert->bindValue(7, $_POST['subscr_id'], PDO::PARAM_STR);
						$Insert->bindValue(8, 0000, PDO::PARAM_INT);
						$Insert->execute();
						
						$Update = $db->prepare("UPDATE User SET CurrencyCoins = CurrencyCoins + ".$PlanCoins.", NextUpgradeCoinPay = ".(time() + 86400).", VIP = ".$PlanID.", VIP_Recurring = 0, VIP_Expires = ".(time() + 2678400)." WHERE ID = ".$gU->ID."");
						$Update->execute();
						
						$Insert = $db->prepare("INSERT INTO UserBadge (UserID, AchievementID) VALUES(".$gU->ID.", ".($PlanID+8).")");
						$Insert->execute();
						
						// Discord verification
						if ($gU->DiscordId > 0 && $gU->VIP == 0) {
							$ch = curl_init();
							curl_setopt($ch, CURLOPT_URL, 'http://discordapi.brickplanet.com/modify-user-vip?userId='.$gU->DiscordId.'&action=add-role&level=' . $PlanID);
							curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
							$result = curl_exec($ch);
							curl_close($ch);
						} else if ($gU->DiscordId > 0 && $gU->VIP > 0) {
							$ch = curl_init();
							curl_setopt($ch, CURLOPT_URL, 'http://discordapi.brickplanet.com/modify-user-vip?userId='.$gU->DiscordId.'&action=change-role&level=' . $gU->VIP . '&newlevel=' . $PlanID);
							curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
							$result = curl_exec($ch);
							curl_close($ch);
						}
						
						if ($PlanID == 1) {
							
							$Count = $db->prepare("SELECT COUNT(*) FROM UserInventory WHERE UserID = ".$gU->ID." AND ItemID = 19141");
							$Count->execute();
							$Count = $Count->fetchColumn();
							
							if ($Count == 0) {
								$Insert = $db->prepare("INSERT INTO UserInventory (UserID, ItemID, TimeCreated) VALUES(".$gU->ID.", 19141, ".time().")");
								$Insert->execute();
							}
							
						} else if ($PlanID == 2) {
							
							$Count = $db->prepare("SELECT COUNT(*) FROM UserInventory WHERE UserID = ".$gU->ID." AND ItemID = 18595");
							$Count->execute();
							$Count = $Count->fetchColumn();
							
							if ($Count == 0) {
								$Insert = $db->prepare("INSERT INTO UserInventory (UserID, ItemID, TimeCreated) VALUES(".$gU->ID.", 18595, ".time().")");
								$Insert->execute();
							}
							
							$Count = $db->prepare("SELECT COUNT(*) FROM UserInventory WHERE UserID = ".$gU->ID." AND ItemID = 18611");
							$Count->execute();
							$Count = $Count->fetchColumn();
							
							if ($Count == 0) {
								$Insert = $db->prepare("INSERT INTO UserInventory (UserID, ItemID, TimeCreated) VALUES(".$gU->ID.", 18611, ".time().")");
								$Insert->execute();
							}
							
						} else if ($PlanID == 3) {
							
							$Count = $db->prepare("SELECT COUNT(*) FROM UserInventory WHERE UserID = ".$gU->ID." AND ItemID = 18555");
							$Count->execute();
							$Count = $Count->fetchColumn();
							
							if ($Count == 0) {
								$Insert = $db->prepare("INSERT INTO UserInventory (UserID, ItemID, TimeCreated) VALUES(".$gU->ID.", 18555, ".time().")");
								$Insert->execute();
							}
							
							$Count = $db->prepare("SELECT COUNT(*) FROM UserInventory WHERE UserID = ".$gU->ID." AND ItemID = 18562");
							$Count->execute();
							$Count = $Count->fetchColumn();
							
							if ($Count == 0) {
								$Insert = $db->prepare("INSERT INTO UserInventory (UserID, ItemID, TimeCreated) VALUES(".$gU->ID.", 18562, ".time().")");
								$Insert->execute();
							}
							
							$Count = $db->prepare("SELECT COUNT(*) FROM UserInventory WHERE UserID = ".$gU->ID." AND ItemID = 18586");
							$Count->execute();
							$Count = $Count->fetchColumn();
							
							if ($Count == 0) {
								$Insert = $db->prepare("INSERT INTO UserInventory (UserID, ItemID, TimeCreated) VALUES(".$gU->ID.", 18586, ".time().")");
								$Insert->execute();
							}
							
							$Count = $db->prepare("SELECT COUNT(*) FROM UserInventory WHERE UserID = ".$gU->ID." AND ItemID = 18589");
							$Count->execute();
							$Count = $Count->fetchColumn();
							
							if ($Count == 0) {
								$Insert = $db->prepare("INSERT INTO UserInventory (UserID, ItemID, TimeCreated) VALUES(".$gU->ID.", 18589, ".time().")");
								$Insert->execute();
							}
							
						}
						
					}
					
				}
				
			} else if ($_POST['payment_status'] == 'Completed' && $receiver_email == 'corporate@brickplanet.com') {
				
				switch ($item_name) {
					case '1,000 Bits';
						$PlanID = 4;
						$PlanCoins = 1000;
						break;
					case '5,000 Bits';
						$PlanID = 5;
						$PlanCoins = 5000;
						break;
					case '10,000 Bits';
						$PlanID = 6;
						$PlanCoins = 10000;
						break;
					case '25,000 Bits';
						$PlanID = 7;
						$PlanCoins = 25000;
						break;
					case '51,000 Bits';
						$PlanID = 8;
						$PlanCoins = 51000;
						break;
					case '105,000 Bits';
						$PlanID = 9;
						$PlanCoins = 105000;
						break;
					case '160,000 Bits';
						$PlanID = 10;
						$PlanCoins = 160000;
						break;
					case '1,000 Credits':
						$PlanID = 11;
						$PlanCredits = 1000;
						break;
					case '4,500 Credits':
						$PlanID = 12;
						$PlanCredits = 4500;
						break;
					case '7,500 Credits':
						$PlanID = 13;
						$PlanCredits = 7500;
						break;
					case '10,000 Credits':
						$PlanID = 14;
						$PlanCredits = 10000;
						break;
				}
				
				if (!isset($PlanID)) {
					
					// Custom credits amount
					
					$item_name = str_replace([' Credits', ','], '', $item_name);
					
					if ($item_name >= 500 && $item_name <= 25000 && number_format(($item_name/100), 2) == $payment_amount) {
						
						$PlanID = 15;
						$PlanCredits = $item_name;
						
					}
					
				}
				
				if (isset($PlanID)) {
				
					$Insert = $db->prepare("INSERT INTO UserPaymentHistory (UserID, PlanID, PaymentType, TimePayment, PayerName, PayerEmail, PayerAddress, PayerCity, PayerState, PayerCountry, TransactionID, LastFour) VALUES(".$gU->ID.", ".$PlanID.", 1, ".time().", ?, '".$gU->Email."', ?, ?, ?, ?, ?, ?)");
					$Insert->bindValue(1, $_POST['first_name'].' '.$_POST['last_name'], PDO::PARAM_STR);
					$Insert->bindValue(2, $_POST['address_street'], PDO::PARAM_STR);
					$Insert->bindValue(3, $_POST['address_city'], PDO::PARAM_STR);
					$Insert->bindValue(4, $_POST['address_state'], PDO::PARAM_STR);
					$Insert->bindValue(5, $_POST['address_country_code'], PDO::PARAM_STR);
					$Insert->bindValue(6, $txn_id, PDO::PARAM_STR);
					$Insert->bindValue(7, 0000, PDO::PARAM_INT);
					$Insert->execute();
					
					if (!isset($PlanCredits)) {
					
						$Update = $db->prepare("UPDATE User SET CurrencyCoins = CurrencyCoins + ".$PlanCoins." WHERE ID = ".$gU->ID."");
						$Update->execute();
					
					} else {
						
						$Update = $db->prepare("UPDATE User SET CurrencyCredits = CurrencyCredits + ".$PlanCredits." WHERE ID = ".$gU->ID."");
						$Update->execute();
						
					}
				
				}
				
			} else if ($txn_type == 'subscr_payment') {
				
				$Update = $db->prepare("UPDATE User SET VIP_Expires = ".(time() + 2678400)." WHERE ID = ".$gU->ID."");
				$Update->execute();
				
			} else if ($txn_type == 'subscr_cancel') {
				
				$Update = $db->prepare("UPDATE User SET VIP_Recurring = 0 WHERE ID = ".$gU->ID."");
				$Update->execute();
				
			} else if ($txn_type == 'subscr_eot') {
				
				$Update = $db->prepare("UPDATE User SET VIP = 0, VIP_Recurring = 0, VIP_Expires = 0 WHERE ID = ".$gU->ID."");
				$Update->execute();
				
			}
			
			$cache->delete($gU->ID);
			
		}
		
	} else if (strcmp ($res, "INVALID") == 0) {
	
		
	
	}
	
	