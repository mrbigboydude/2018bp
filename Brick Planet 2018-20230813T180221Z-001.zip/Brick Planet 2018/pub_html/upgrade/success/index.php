<?php
require_once($_SERVER['DOCUMENT_ROOT']."/../private/header.php");
	
	requireLogin();
		
	echo '
	<div class="grid-x grid-margin-x">
		<div class="large-6 large-offset-3 cell">
			<div class="container border-r md-padding">
				<h4><span><i class="material-icons upgrade-success-icon">check_circle</i></span><span>Thank you for your purchase!</span></h4>
				<p>Your purchase has succeeded! Your order should be activated shortly.</p>
				<p>However, your order may not process immediately if you used an e-check via PayPal or if your payment was flagged for additional review.</p>
				<p>If you have any questions with your recent payment, please do not hesitate to contact us via email at <a href="mailto:hello@brickplanet.com">hello@brickplanet.com</a>, or calling us at +1 (970) 445-1220.</p>
			</div>
		</div>
	</div>
	';
	
require_once($_SERVER['DOCUMENT_ROOT']."/../private/footer.php");